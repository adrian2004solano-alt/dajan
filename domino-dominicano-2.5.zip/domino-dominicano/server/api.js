// Dominó Dominicano · API (cuentas, bonos, ranking, soporte y administración)
import { timingSafeEqual, createHash } from 'node:crypto';
import { call, now, store } from './store/index.js';
import { CFG } from './config.js';
import { clean, limiter } from './moderation.js';
import * as U from './users.js';

const authLimit = limiter(10, 60000), guestLimit = limiter(CFG.GUEST_PER_HOUR, 3600000), ticketLimit = limiter(6, 3600000), msgLimit = limiter(20, 3600000), adminLimit = limiter(30, 60000);
const CATS = ['Cuenta', 'Saldo', 'Partida', 'Reportar a un jugador', 'Sugerencia', 'Otro'];

export function makeApi(hub) {
  const routes = [];
  const on = (method, path, fn, opts = {}) => routes.push({ method, re: new RegExp('^' + path.replace(/:(\w+)/g, '(?<$1>[^/]+)') + '$'), fn, opts });

  // ---- cuentas ----
  on('POST', '/api/guest', async (c) => {
    if (!guestLimit(c.ip)) return [429, { error: 'Demasiadas cuentas nuevas desde tu conexión. Intenta más tarde.' }];
    const u = await U.createGuest();
    return { token: await U.newSession(u.id), me: U.publicMe(u) };
  });
  on('POST', '/api/login', async (c) => {
    if (!authLimit(c.ip)) return [429, { error: 'Demasiados intentos. Espera un minuto.' }];
    const r = await U.login(c.body.name, c.body.password);
    if (r.error) return [400, r];
    return { token: r.token, me: U.publicMe(r.user) };
  });
  on('POST', '/api/register', async (c) => {
    if (!authLimit(c.ip)) return [429, { error: 'Demasiados intentos. Espera un minuto.' }];
    if (c.user.registered) return [400, { error: 'Tu cuenta ya está registrada.' }];
    const r = await U.register(c.user, c.body.name, c.body.email, c.body.password, c.body.adult);
    return r.error ? [400, r] : r;
  }, { auth: true });
  on('POST', '/api/register/resend', async (c) => {
    if (!authLimit(c.ip)) return [429, { error: 'Demasiados intentos. Espera un minuto.' }];
    const r = await U.resendCode(c.user);
    return r.error ? [400, r] : r;
  }, { auth: true });
  on('POST', '/api/register/verify', async (c) => {
    if (!authLimit(c.ip)) return [429, { error: 'Demasiados intentos. Espera un minuto.' }];
    const r = await U.verify(c.user, c.body.code);
    if (r.error) return [400, r];
    hub.setUser(r.user);
    hub.notify(c.user.id, { t: 'me', me: U.publicMe(r.user) });
    return { me: U.publicMe(r.user) };
  }, { auth: true });
  on('POST', '/api/logout', async (c) => { await U.endSession(c.token); return { ok: true }; }, { auth: true });
  on('GET', '/api/me', (c) => ({ me: U.publicMe(c.user) }), { auth: true });
  on('POST', '/api/profile', async (c) => {
    const r = await U.updateProfile(c.user, c.body || {});
    if (r.error) return [400, r];
    hub.setUser(r.user);
    hub.notify(c.user.id, { t: 'me', me: U.publicMe(r.user) });
    return { me: U.publicMe(r.user) };
  }, { auth: true });

  // ---- monedas ----
  on('POST', '/api/daily', async (c) => { const r = await U.claimDaily(c.user); if (r.error) return [400, r]; await hub.refreshUser(c.user.id); hub.notify(c.user.id, { t: 'coins', coins: r.coins, delta: r.amount, reason: 'bono diario' }); return r; }, { auth: true });
  on('POST', '/api/rescue', async (c) => { const r = await U.claimRescue(c.user); if (r.error) return [400, r]; await hub.refreshUser(c.user.id); hub.notify(c.user.id, { t: 'coins', coins: r.coins, delta: r.amount, reason: 'bono de rescate' }); return r; }, { auth: true });
  on('GET', '/api/history', async (c) => ({ items: await U.history(c.user) }), { auth: true });
  on('GET', '/api/leaderboard', async () => ({ items: await U.leaderboard() }));
  on('GET', '/api/health', async () => {
    let db = true; try { await call('chat_recent', { n: 1 }); } catch (e) { db = false; console.error('health', e.message); }
    return [db ? 200 : 503, { ok: db, db: store.kind, dbOk: db, ...hub.stats() }];
  });

  // ---- servicio al cliente ----
  const ticketOut = (t) => ({ id: t.id, category: t.category, subject: t.subject, status: t.status, unread: !!t.unread_user, created: t.created, updated: t.updated });
  on('GET', '/api/tickets', async (c) => ({ items: (await call('tickets_mine', { uid: c.user.id })).map(ticketOut) }), { auth: true });
  on('POST', '/api/tickets', async (c) => {
    if (!ticketLimit(c.user.id)) return [429, { error: 'Ya enviaste varias consultas. Te responderemos pronto.' }];
    const cat = CATS.includes(c.body.category) ? c.body.category : 'Otro';
    const subject = clean(c.body.subject, 80), text = clean(c.body.text, 2000);
    if (subject.length < 3 || text.length < 5) return [400, { error: 'Escribe un asunto y cuéntanos qué pasó.' }];
    return { id: await call('ticket_create', { uid: c.user.id, category: cat, subject, text, now: now() }) };
  }, { auth: true });
  on('GET', '/api/tickets/:id', async (c) => {
    const r = await call('ticket_get_mine', { id: +c.params.id || 0, uid: c.user.id });
    if (!r) return [404, { error: 'No encontramos esa consulta.' }];
    return { ticket: ticketOut(r.ticket), messages: r.messages };
  }, { auth: true });
  on('POST', '/api/tickets/:id/messages', async (c) => {
    if (!msgLimit(c.user.id)) return [429, { error: 'Más despacio, por favor.' }];
    const text = clean(c.body.text, 2000); if (text.length < 2) return [400, { error: 'Escribe tu mensaje.' }];
    if (!(await call('ticket_add_msg', { id: +c.params.id || 0, uid: c.user.id, text, now: now() }))) return [404, { error: 'No encontramos esa consulta.' }];
    return { ok: true };
  }, { auth: true });

  // ---- salas privadas (invitación por enlace o código) ----
  on('GET', '/api/salas/:code', (c) => {
    const s = hub.salaInfo(c.params.code);
    return s ? { sala: s } : [404, { error: 'Esa sala no existe o ya cerró.' }];
  });

  // ---- administración (requiere ADMIN_KEY) ----
  const A = (fn) => (c) => fn(c);
  on('GET', '/api/admin/stats', A(async () => ({ ...hub.stats(), ...(await call('admin_stats', { now: now() })) })), { admin: true });
  on('GET', '/api/admin/revenue', A(async () => ({ fee: CFG.PLATFORM_FEE, ...(await call('admin_revenue', { now: now(), tz_ms: CFG.TZ_OFFSET_H * 3600e3 })) })), { admin: true });
  on('GET', '/api/admin/tickets', A(async (c) => {
    const st = ['abierto', 'respondido', 'cerrado'].includes(c.query.get('estado')) ? c.query.get('estado') : null;
    return { items: await call('admin_tickets', { status: st }) };
  }), { admin: true });
  on('GET', '/api/admin/tickets/:id', A(async (c) => {
    const r = await call('admin_ticket', { id: +c.params.id || 0 });
    return r || [404, { error: 'No existe' }];
  }), { admin: true });
  on('POST', '/api/admin/tickets/:id/reply', A(async (c) => {
    const text = String(c.body.text || '').trim().slice(0, 4000); if (!text) return [400, { error: 'Escribe la respuesta' }];
    const t = await call('admin_reply', { id: +c.params.id || 0, text, close: !!c.body.close, now: now() });
    if (!t) return [404, { error: 'No existe' }];
    hub.notify(t.user_id, { t: 'notice', kind: 'ticket', id: +c.params.id, msg: 'Soporte respondió tu consulta: ' + t.subject });
    return { ok: true };
  }), { admin: true });
  on('POST', '/api/admin/tickets/:id/close', A(async (c) => { await call('admin_ticket_close', { id: +c.params.id || 0, now: now() }); return { ok: true }; }), { admin: true });
  on('GET', '/api/admin/reports', A(async () => ({ items: await call('admin_reports', {}) })), { admin: true });
  on('POST', '/api/admin/reports/:id/resolve', A(async (c) => { await call('admin_report_resolve', { id: +c.params.id || 0 }); return { ok: true }; }), { admin: true });
  on('POST', '/api/admin/chat/:id/delete', A(async (c) => { await hub.deleteChat(+c.params.id || 0); return { ok: true }; }), { admin: true });
  on('GET', '/api/admin/chat', A(async () => ({ items: await call('admin_chat', {}) })), { admin: true });
  on('GET', '/api/admin/users', A(async (c) => ({ items: await call('admin_users', { q: String(c.query.get('q') || '').trim().toLowerCase().slice(0, 40) }) })), { admin: true });
  on('POST', '/api/admin/users/:id/coins', A(async (c) => {
    const id = +c.params.id || 0, d = Math.trunc(+c.body.delta || 0); if (!d || Math.abs(d) > 1e6) return [400, { error: 'Cantidad inválida' }];
    const bal = await U.moveCoins(id, d, 'ajuste de soporte' + (c.body.reason ? ': ' + clean(c.body.reason, 80) : ''));
    if (bal == null) return [400, { error: 'El saldo no puede quedar negativo' }];
    await hub.refreshUser(id);
    hub.notify(id, { t: 'coins', coins: bal, delta: d, reason: 'ajuste de soporte' });
    return { coins: bal };
  }), { admin: true });
  on('POST', '/api/admin/users/:id/mute', A(async (c) => {
    const id = +c.params.id || 0, min = Math.max(0, Math.min(60 * 24 * 30, +c.body.minutes || 0));
    await call('admin_mute', { id, until: min ? now() + min * 60e3 : 0 });
    await hub.refreshUser(id);
    hub.notify(id, { t: 'notice', kind: 'mute', msg: min ? `No puedes escribir en el chat por ${min} minutos.` : 'Ya puedes volver a escribir en el chat.' });
    return { ok: true };
  }), { admin: true });
  on('POST', '/api/admin/users/:id/ban', A(async (c) => {
    const id = +c.params.id || 0, ban = !!c.body.ban, reason = clean(c.body.reason || '', 200);
    await call('admin_ban', { id, ban, reason });
    if (ban) hub.kick(id, reason);
    return { ok: true };
  }), { admin: true });

  // ---- despacho ----
  const adminOk = (key) => {
    if (!CFG.ADMIN_KEY || typeof key !== 'string') return false;
    const a = createHash('sha256').update(key).digest(), b = createHash('sha256').update(CFG.ADMIN_KEY).digest();
    return timingSafeEqual(a, b);
  };
  return async function handle(req, res, url, ip, readBody, send) {
    const r = routes.find((x) => x.method === req.method && x.re.test(url.pathname));
    if (!r) return send(res, 404, { error: 'No existe' });
    const c = { ip, query: url.searchParams, params: url.pathname.match(r.re).groups || {}, body: {} };
    if (req.method === 'POST') { try { c.body = await readBody(req); } catch (e) { return send(res, 400, { error: 'Datos inválidos' }); } }
    if (r.opts.admin) {
      if (!CFG.ADMIN_KEY) return send(res, 403, { error: 'El panel está desactivado: falta configurar ADMIN_KEY en el servidor.' });
      if (!adminLimit(ip)) return send(res, 429, { error: 'Demasiadas peticiones' });
      if (!adminOk(req.headers['x-admin-key'])) return send(res, 401, { error: 'Clave incorrecta' });
    }
    if (r.opts.auth) {
      const h = req.headers.authorization || ''; c.token = h.startsWith('Bearer ') ? h.slice(7) : '';
      try { c.user = await U.userFromToken(c.token); } catch (e) { console.error('api auth', e.message); return send(res, 503, { error: 'El servidor no pudo leer tu cuenta. Intenta otra vez.' }); }
      if (!c.user) return send(res, 401, { error: 'Tu sesión venció. Vuelve a entrar.' });
      if (c.user.banned) return send(res, 403, { error: 'Cuenta suspendida' });
    }
    try {
      const out = await r.fn(c);
      if (Array.isArray(out)) return send(res, out[0], out[1]);
      return send(res, 200, out);
    } catch (e) { console.error('api', url.pathname, e); return send(res, 500, { error: 'Algo salió mal. Intenta otra vez.' }); }
  };
}
