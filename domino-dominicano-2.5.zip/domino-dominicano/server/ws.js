// Dominó Dominicano · WebSocket mínimo (RFC 6455), sin dependencias.
// Solo lo que el juego necesita: mensajes de texto, ping/pong, cierre y límite de tamaño.
import { createHash } from 'node:crypto';
import { EventEmitter } from 'node:events';

const GUID = '258EAFA5-E914-47DA-95CA-C5AB0DC85B11';
const MAX = 64 * 1024; // tamaño máximo de un mensaje

export class Socket extends EventEmitter {
  constructor(sock) {
    super();
    this.sock = sock; this.buf = Buffer.alloc(0); this.frags = []; this.open = true; this.alive = true;
    sock.setNoDelay(true);
    sock.on('data', (d) => this.onData(d));
    sock.on('close', () => this.closed());
    sock.on('error', () => this.closed());
  }
  onData(d) {
    this.alive = true;
    this.buf = this.buf.length ? Buffer.concat([this.buf, d]) : d;
    while (this.open) {
      const b = this.buf;
      if (b.length < 2) return;
      const fin = (b[0] & 0x80) !== 0, op = b[0] & 0x0f, masked = (b[1] & 0x80) !== 0;
      let len = b[1] & 0x7f, off = 2;
      if (len === 126) { if (b.length < 4) return; len = b.readUInt16BE(2); off = 4; }
      else if (len === 127) { if (b.length < 10) return; const hi = b.readUInt32BE(2); len = b.readUInt32BE(6); if (hi) return this.fail(1009); off = 10; }
      if (!masked) return this.fail(1002);
      if (len > MAX) return this.fail(1009);
      if (b.length < off + 4 + len) return;
      const mask = b.subarray(off, off + 4), data = Buffer.from(b.subarray(off + 4, off + 4 + len));
      for (let i = 0; i < data.length; i++) data[i] ^= mask[i & 3];
      this.buf = b.subarray(off + 4 + len);
      if (op === 0x8) { this.close(1000); return; }
      if (op === 0x9) { this.frame(0xA, data); continue; }
      if (op === 0xA) { this.alive = true; continue; }
      if (op === 0x1 || op === 0x2 || op === 0x0) {
        this.frags.push(data);
        const total = this.frags.reduce((s, f) => s + f.length, 0);
        if (total > MAX) return this.fail(1009);
        if (fin) { const msg = Buffer.concat(this.frags).toString('utf8'); this.frags = []; this.emit('message', msg); }
        continue;
      }
      return this.fail(1002);
    }
  }
  frame(op, data) {
    if (!this.open) return;
    const len = data.length;
    const head = len < 126 ? Buffer.from([0x80 | op, len]) : len < 65536 ? Buffer.from([0x80 | op, 126, len >> 8, len & 255]) : (() => { const h = Buffer.alloc(10); h[0] = 0x80 | op; h[1] = 127; h.writeUInt32BE(0, 2); h.writeUInt32BE(len, 6); return h; })();
    try { this.sock.write(Buffer.concat([head, data])); } catch { this.closed(); }
  }
  send(obj) { this.frame(0x1, Buffer.from(typeof obj === 'string' ? obj : JSON.stringify(obj), 'utf8')); }
  ping() { this.frame(0x9, Buffer.alloc(0)); }
  fail(code) { this.close(code); }
  close(code = 1000) {
    if (!this.open) return;
    const b = Buffer.alloc(2); b.writeUInt16BE(code); this.frame(0x8, b);
    this.open = false; try { this.sock.end(); } catch {} this.closed();
  }
  closed() { if (this.done) return; this.done = true; this.open = false; try { this.sock.destroy(); } catch {} this.emit('close'); }
}

// Acepta la conexión (handshake). Devuelve el Socket o null si la petición no es válida.
export function accept(req, sock) {
  const key = req.headers['sec-websocket-key'];
  if (!key || (req.headers.upgrade || '').toLowerCase() !== 'websocket' || req.headers['sec-websocket-version'] !== '13') {
    sock.end('HTTP/1.1 400 Bad Request\r\n\r\n'); return null;
  }
  const acc = createHash('sha1').update(key + GUID).digest('base64');
  sock.write('HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Accept: ' + acc + '\r\n\r\n');
  return new Socket(sock);
}

// Revisa cada 25 s que las conexiones sigan vivas
export function heartbeat(set) {
  return setInterval(() => {
    for (const s of set) { if (!s.alive) { s.close(1001); continue; } s.alive = false; s.ping(); }
  }, 25000);
}
