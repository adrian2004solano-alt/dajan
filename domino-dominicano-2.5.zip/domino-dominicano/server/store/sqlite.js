// Dominó Dominicano · datos en SQLite (incluido en Node.js 22, sin instalar nada)
// Para probar en tu computadora o para un servidor pequeño con disco persistente.
// Cada operación recibe UN objeto y devuelve datos simples (lo mismo que las funciones dd_* de Supabase).
import { DatabaseSync } from 'node:sqlite';
import { mkdirSync } from 'node:fs';
import { join } from 'node:path';

export function createSqliteStore(CFG) {
  mkdirSync(CFG.DATA_DIR, { recursive: true });
  const db = new DatabaseSync(process.env.DB_FILE || join(CFG.DATA_DIR, 'domino.db'));
  db.exec('PRAGMA journal_mode = WAL; PRAGMA foreign_keys = ON; PRAGMA busy_timeout = 3000;');
  db.exec(`
CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL, name_lc TEXT NOT NULL UNIQUE,
  pass TEXT, salt TEXT, registered INTEGER NOT NULL DEFAULT 0,
  coins INTEGER NOT NULL DEFAULT 0,
  avatar TEXT, prefs TEXT,
  games INTEGER NOT NULL DEFAULT 0, wins INTEGER NOT NULL DEFAULT 0, coins_won INTEGER NOT NULL DEFAULT 0,
  daily_day INTEGER NOT NULL DEFAULT 0, rescue_at INTEGER NOT NULL DEFAULT 0,
  muted_until INTEGER NOT NULL DEFAULT 0, banned INTEGER NOT NULL DEFAULT 0, ban_reason TEXT,
  created INTEGER NOT NULL, last_seen INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS sessions (
  token_hash TEXT PRIMARY KEY, user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  created INTEGER NOT NULL, last INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS ledger (
  id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  delta INTEGER NOT NULL, balance INTEGER NOT NULL, reason TEXT NOT NULL, ref TEXT, created INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS ledger_user ON ledger(user_id, id);
CREATE TABLE IF NOT EXISTS chat (
  id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL, name TEXT NOT NULL, avatar TEXT,
  text TEXT NOT NULL, created INTEGER NOT NULL, deleted INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS reports (
  id INTEGER PRIMARY KEY AUTOINCREMENT, reporter_id INTEGER NOT NULL, target_id INTEGER, msg_id INTEGER,
  text TEXT, reason TEXT, created INTEGER NOT NULL, resolved INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS tickets (
  id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  category TEXT NOT NULL, subject TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'abierto',
  unread_user INTEGER NOT NULL DEFAULT 0, unread_admin INTEGER NOT NULL DEFAULT 1,
  created INTEGER NOT NULL, updated INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS ticket_msgs (
  id INTEGER PRIMARY KEY AUTOINCREMENT, ticket_id INTEGER NOT NULL REFERENCES tickets(id) ON DELETE CASCADE,
  from_admin INTEGER NOT NULL DEFAULT 0, text TEXT NOT NULL, created INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS matches (
  id TEXT PRIMARY KEY, mode TEXT NOT NULL, stake INTEGER NOT NULL, status TEXT NOT NULL,
  players TEXT NOT NULL, result TEXT, created INTEGER NOT NULL, ended INTEGER, charged TEXT, room_code TEXT
);
`);
  // bases creadas con la versión 2.0 no tenían estas columnas
  try { db.exec('ALTER TABLE users ADD COLUMN email TEXT'); } catch { /* ya existe */ }
  db.exec(`CREATE UNIQUE INDEX IF NOT EXISTS users_email ON users(email) WHERE email IS NOT NULL;
CREATE TABLE IF NOT EXISTS email_codes (
  user_id INTEGER PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE, email TEXT NOT NULL, payload TEXT,
  code_hash TEXT NOT NULL, expires INTEGER NOT NULL, attempts INTEGER NOT NULL DEFAULT 0, sent_at INTEGER NOT NULL
);`);
  for (const col of ['charged TEXT', 'room_code TEXT', 'collected INTEGER NOT NULL DEFAULT 0', 'fee INTEGER NOT NULL DEFAULT 0', 'paid INTEGER NOT NULL DEFAULT 0']) { try { db.exec('ALTER TABLE matches ADD COLUMN ' + col); } catch { /* ya existe */ } }

  const q = (sql) => db.prepare(sql);
  const tx = (fn) => { db.exec('BEGIN'); try { const r = fn(); db.exec('COMMIT'); return r; } catch (e) { db.exec('ROLLBACK'); throw e; } };
  const one = (row) => row || null;
  const isUnique = (e) => /UNIQUE/i.test(String(e && e.message));
  const uniqueWhich = (e) => (/email/i.test(String(e && e.message)) ? 'correo' : 'nombre');

  const S = {
    user: q('SELECT * FROM users WHERE id = ?'),
    userLc: q('SELECT * FROM users WHERE name_lc = ?'),
    updCoins: q('UPDATE users SET coins = coins + ? WHERE id = ? AND coins + ? >= 0'),
    coins: q('SELECT coins FROM users WHERE id = ?'),
    ledger: q('INSERT INTO ledger (user_id, delta, balance, reason, ref, created) VALUES (?, ?, ?, ?, ?, ?)'),
    stat: q('UPDATE users SET games = games + 1, wins = wins + ?, coins_won = coins_won + ? WHERE id = ?'),
    endMatch: q('UPDATE matches SET status = ?, result = ?, ended = ? WHERE id = ?')
  };
  function move(uid, delta, reason, ref, now) {
    delta = Math.trunc(delta);
    if (!S.updCoins.run(delta, uid, delta).changes) return null;
    const bal = S.coins.get(uid).coins;
    S.ledger.run(uid, delta, bal, reason, ref ?? null, now);
    return bal;
  }
  const ticketMsgs = (id) => q('SELECT from_admin AS admin, text, created FROM ticket_msgs WHERE ticket_id = ? ORDER BY id').all(id);

  const ops = {
    // ---- cuentas ----
    user_get: ({ id }) => one(S.user.get(id)),
    user_by_name: ({ name_lc }) => one(S.userLc.get(name_lc)),
    guest_create: ({ name, name_lc, avatar, prefs, coins, now }) => {
      try {
        return tx(() => {
          const r = q('INSERT INTO users (name, name_lc, coins, avatar, prefs, created, last_seen) VALUES (?, ?, 0, ?, ?, ?, ?)').run(name, name_lc ?? name.toLowerCase(), avatar, prefs, now, now);
          const id = Number(r.lastInsertRowid); if (coins) move(id, coins, 'bienvenida', null, now);
          return S.user.get(id);
        });
      } catch (e) { if (isUnique(e)) return null; throw e; }
    },
    session_create: ({ hash, uid, now }) => { q('INSERT INTO sessions (token_hash, user_id, created, last) VALUES (?, ?, ?, ?)').run(hash, uid, now, now); return true; },
    session_user: ({ hash, now }) => {
      const s = q('SELECT user_id FROM sessions WHERE token_hash = ?').get(hash); if (!s) return null;
      q('UPDATE sessions SET last = ? WHERE token_hash = ?').run(now, hash); q('UPDATE users SET last_seen = ? WHERE id = ?').run(now, s.user_id);
      return one(S.user.get(s.user_id));
    },
    session_delete: ({ hash }) => { q('DELETE FROM sessions WHERE token_hash = ?').run(hash); return true; },
    user_register: ({ id, name, name_lc, pass, salt, email }) => {
      try { q('UPDATE users SET name = ?, name_lc = ?, pass = ?, salt = ?, registered = 1, email = COALESCE(?, email) WHERE id = ?').run(name, name_lc ?? name.toLowerCase(), pass, salt, email ?? null, id); }
      catch (e) { if (isUnique(e)) return { error: uniqueWhich(e) }; throw e; }
      return { user: S.user.get(id) };
    },
    user_update: ({ id, name, name_lc, avatar, prefs }) => {
      try {
        tx(() => {
          if (name != null) q('UPDATE users SET name = ?, name_lc = ? WHERE id = ?').run(name, name_lc ?? name.toLowerCase(), id);
          if (avatar != null) q('UPDATE users SET avatar = ? WHERE id = ?').run(avatar, id);
          if (prefs != null) q('UPDATE users SET prefs = ? WHERE id = ?').run(prefs, id);
        });
      } catch (e) { if (isUnique(e)) return { error: 'nombre' }; throw e; }
      return { user: S.user.get(id) };
    },
    user_by_email: ({ email }) => one(q('SELECT * FROM users WHERE email = ?').get(email)),
    email_code_set: ({ uid, email, payload, code_hash, expires, now }) => {
      q('INSERT INTO email_codes (user_id, email, payload, code_hash, expires, attempts, sent_at) VALUES (?, ?, ?, ?, ?, 0, ?) ON CONFLICT(user_id) DO UPDATE SET email = excluded.email, payload = COALESCE(excluded.payload, email_codes.payload), code_hash = excluded.code_hash, expires = excluded.expires, attempts = 0, sent_at = excluded.sent_at')
        .run(uid, email, payload ? JSON.stringify(payload) : null, code_hash, expires, now);
      return true;
    },
    email_code_get: ({ uid }) => { const r = q('SELECT email, payload FROM email_codes WHERE user_id = ?').get(uid); return r ? { email: r.email, payload: r.payload ? JSON.parse(r.payload) : null } : null; },
    email_code_check: ({ uid, code_hash, now }) => {
      const r = q('SELECT * FROM email_codes WHERE user_id = ?').get(uid);
      if (!r) return { error: 'ninguno' };
      if (r.attempts >= 5) return { error: 'intentos' };
      if (now > r.expires) return { error: 'vencido' };
      if (r.code_hash !== code_hash) { q('UPDATE email_codes SET attempts = attempts + 1 WHERE user_id = ?').run(uid); return { error: 'incorrecto' }; }
      q('DELETE FROM email_codes WHERE user_id = ?').run(uid);
      return { ok: true, email: r.email, payload: r.payload ? JSON.parse(r.payload) : null };
    },
    claim_daily: ({ id, day, amount, now }) => tx(() => {
      if (!q('UPDATE users SET daily_day = ? WHERE id = ? AND daily_day < ?').run(day, id, day).changes) return null;
      return move(id, amount, 'bono diario', null, now);
    }),
    claim_rescue: ({ id, now, amount, every_ms, min_stake }) => tx(() => {
      if (!q('UPDATE users SET rescue_at = ? WHERE id = ? AND coins < ? AND ? - rescue_at >= ?').run(now, id, min_stake, now, every_ms).changes) return null;
      return move(id, amount, 'bono de rescate', null, now);
    }),
    leaderboard: () => q('SELECT id, name, avatar, wins, games FROM users WHERE banned = 0 AND games > 0 ORDER BY wins DESC, games ASC LIMIT 25').all(), // sin saldos: es dinero real
    history: ({ uid }) => q('SELECT delta, balance, reason, created FROM ledger WHERE user_id = ? ORDER BY id DESC LIMIT 40').all(uid),
    move_coins: ({ uid, delta, reason, ref, now }) => tx(() => move(uid, delta, reason, ref, now)),

    // ---- chat ----
    chat_add: ({ uid, name, avatar, text, now }) => {
      const id = Number(q('INSERT INTO chat (user_id, name, avatar, text, created) VALUES (?, ?, ?, ?, ?)').run(uid, name, avatar, text, now).lastInsertRowid);
      if (id % 200 === 0) q('DELETE FROM chat WHERE id < ?').run(id - 5000);
      return id;
    },
    chat_recent: ({ n }) => q('SELECT id, user_id AS uid, name, avatar, text, created AS ts FROM chat WHERE deleted = 0 ORDER BY id DESC LIMIT ?').all(n).reverse(),
    chat_get: ({ id }) => one(q('SELECT * FROM chat WHERE id = ?').get(id)),
    chat_delete: ({ id }) => { q('UPDATE chat SET deleted = 1 WHERE id = ?').run(id); return true; },
    report_add: ({ reporter, target, msg_id, text, reason, now }) => { q('INSERT INTO reports (reporter_id, target_id, msg_id, text, reason, created) VALUES (?, ?, ?, ?, ?, ?)').run(reporter, target, msg_id, text, reason, now); return true; },

    // ---- partidas ----
    // cobra la apuesta a cada uno (al que no le alcance se queda fuera) y registra la partida como activa
    match_start: ({ id, mode, stake, uids, room_code, fee_rate, now }) => tx(() => {
      const charged = [], failed = [];
      for (const uid of uids) { const bal = move(uid, -stake, 'apuesta', id, now); if (bal == null) failed.push(uid); else charged.push({ uid, coins: bal }); }
      const collected = stake * charged.length, fee = Math.round(collected * (fee_rate || 0));
      if (charged.length) q('INSERT INTO matches (id, mode, stake, status, players, created, charged, room_code, collected, fee) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)')
        .run(id, mode, stake, 'activa', '[]', now, JSON.stringify(charged.map((c) => c.uid)), room_code ?? null, collected, fee);
      return { charged, failed };
    }),
    match_players: ({ id, players }) => { q('UPDATE matches SET players = ? WHERE id = ?').run(JSON.stringify(players), id); return true; },
    // paga el premio a los ganadores, suma estadísticas y cierra la partida (solo una vez)
    match_settle: ({ id, stake, prize, results, result, now }) => tx(() => {
      if (!q("UPDATE matches SET status = 'terminada', result = ?, ended = ? WHERE id = ? AND status = 'activa'").run(JSON.stringify(result), now, id).changes) return [];
      let paid = 0;
      const out = results.map((r) => {
        const coins = r.won ? move(r.uid, prize, 'premio', id, now) : S.coins.get(r.uid)?.coins ?? null;
        if (r.won && coins != null) paid += prize;
        S.stat.run(r.won ? 1 : 0, r.won ? prize - stake : 0, r.uid);
        return { uid: r.uid, coins };
      });
      q('UPDATE matches SET paid = ? WHERE id = ?').run(paid, id);
      return out;
    }),
    // si el servidor se reinició con partidas a medias, se devuelven las apuestas
    match_void_active: ({ now }) => tx(() => {
      const rows = q("SELECT * FROM matches WHERE status = 'activa'").all();
      for (const m of rows) {
        for (const uid of JSON.parse(m.charged || '[]')) move(uid, m.stake, 'devolución (partida interrumpida)', m.id, now);
        S.endMatch.run('anulada', null, now, m.id);
        q('UPDATE matches SET fee = 0, paid = collected WHERE id = ?').run(m.id);
      }
      return rows.length;
    }),

    // ---- soporte ----
    tickets_mine: ({ uid }) => q('SELECT * FROM tickets WHERE user_id = ? ORDER BY updated DESC LIMIT 50').all(uid),
    ticket_create: ({ uid, category, subject, text, now }) => tx(() => {
      const id = Number(q('INSERT INTO tickets (user_id, category, subject, created, updated) VALUES (?, ?, ?, ?, ?)').run(uid, category, subject, now, now).lastInsertRowid);
      q('INSERT INTO ticket_msgs (ticket_id, text, created) VALUES (?, ?, ?)').run(id, text, now);
      return id;
    }),
    ticket_get_mine: ({ id, uid }) => {
      const t = q('SELECT * FROM tickets WHERE id = ? AND user_id = ?').get(id, uid); if (!t) return null;
      q('UPDATE tickets SET unread_user = 0 WHERE id = ?').run(id);
      return { ticket: t, messages: ticketMsgs(id) };
    },
    ticket_add_msg: ({ id, uid, text, now }) => tx(() => {
      if (!q('SELECT id FROM tickets WHERE id = ? AND user_id = ?').get(id, uid)) return false;
      q('INSERT INTO ticket_msgs (ticket_id, text, created) VALUES (?, ?, ?)').run(id, text, now);
      q("UPDATE tickets SET status = 'abierto', unread_admin = 1, updated = ? WHERE id = ?").run(now, id);
      return true;
    }),

    // ---- administración ----
    admin_stats: ({ now }) => ({
      users: q('SELECT COUNT(*) n FROM users').get().n, registered: q('SELECT COUNT(*) n FROM users WHERE registered = 1').get().n,
      matchesToday: q('SELECT COUNT(*) n FROM matches WHERE created > ?').get(now - 86400e3).n,
      openTickets: q("SELECT COUNT(*) n FROM tickets WHERE status = 'abierto'").get().n,
      openReports: q('SELECT COUNT(*) n FROM reports WHERE resolved = 0').get().n,
      coins: q('SELECT COALESCE(SUM(coins),0) n FROM users').get().n
    }),
    // rentabilidad: comisiones (10%) y lo cobrado/pagado en las partidas terminadas
    admin_revenue: ({ now, tz_ms }) => {
      const day = 86400e3, today0 = Math.floor((now + tz_ms) / day) * day - tz_ms;
      const sum = (from) => q("SELECT COUNT(*) AS matches, COALESCE(SUM(collected),0) AS collected, COALESCE(SUM(fee),0) AS fee, COALESCE(SUM(paid),0) AS paid FROM matches WHERE status = 'terminada' AND created >= ?").get(from);
      const add = (o) => Object.assign(o, { net: o.collected - o.paid });
      return {
        today: add(sum(today0)), week: add(sum(today0 - 6 * day)), month: add(sum(today0 - 29 * day)), total: add(sum(0)),
        byMode: q("SELECT mode, COUNT(*) AS matches, COALESCE(SUM(fee),0) AS fee, COALESCE(SUM(collected),0) AS collected FROM matches WHERE status = 'terminada' GROUP BY mode ORDER BY fee DESC").all(),
        daily: q("SELECT ((created + ?) / 86400000) AS d, COUNT(*) AS matches, COALESCE(SUM(fee),0) AS fee FROM matches WHERE status = 'terminada' AND created >= ? GROUP BY d ORDER BY d").all(tz_ms, today0 - 13 * day)
          .map((r) => ({ day: Number(r.d) * day, matches: r.matches, fee: r.fee }))
      };
    },
    admin_tickets: ({ status }) => status
      ? q('SELECT t.*, u.name FROM tickets t JOIN users u ON u.id = t.user_id WHERE status = ? ORDER BY updated DESC LIMIT 100').all(status)
      : q("SELECT t.*, u.name FROM tickets t JOIN users u ON u.id = t.user_id ORDER BY (status = 'abierto') DESC, updated DESC LIMIT 100").all(),
    admin_ticket: ({ id }) => {
      const t = q('SELECT t.*, u.name, u.coins, u.id AS uid FROM tickets t JOIN users u ON u.id = t.user_id WHERE t.id = ?').get(id); if (!t) return null;
      q('UPDATE tickets SET unread_admin = 0 WHERE id = ?').run(id);
      return { ticket: t, messages: ticketMsgs(id) };
    },
    admin_reply: ({ id, text, close, now }) => tx(() => {
      const t = q('SELECT * FROM tickets WHERE id = ?').get(id); if (!t) return null;
      q('INSERT INTO ticket_msgs (ticket_id, from_admin, text, created) VALUES (?, 1, ?, ?)').run(id, text, now);
      q('UPDATE tickets SET status = ?, unread_user = 1, updated = ? WHERE id = ?').run(close ? 'cerrado' : 'respondido', now, id);
      return { user_id: t.user_id, subject: t.subject };
    }),
    admin_ticket_close: ({ id, now }) => { q("UPDATE tickets SET status = 'cerrado', updated = ? WHERE id = ?").run(now, id); return true; },
    admin_reports: () => q('SELECT r.*, a.name AS reporter, b.name AS target, b.muted_until, b.banned FROM reports r LEFT JOIN users a ON a.id = r.reporter_id LEFT JOIN users b ON b.id = r.target_id WHERE resolved = 0 ORDER BY id DESC LIMIT 100').all(),
    admin_report_resolve: ({ id }) => { q('UPDATE reports SET resolved = 1 WHERE id = ?').run(id); return true; },
    admin_chat: () => q('SELECT id, user_id, name, text, created, deleted FROM chat ORDER BY id DESC LIMIT 100').all(),
    admin_users: ({ q: s }) => {
      const cols = 'id, name, coins, registered, games, wins, muted_until, banned, ban_reason, created, last_seen';
      return s ? q(`SELECT ${cols} FROM users WHERE name_lc LIKE ? OR id = ? ORDER BY last_seen DESC LIMIT 50`).all('%' + s + '%', +s || -1)
        : q(`SELECT ${cols} FROM users ORDER BY last_seen DESC LIMIT 50`).all();
    },
    admin_mute: ({ id, until }) => { q('UPDATE users SET muted_until = ? WHERE id = ?').run(until, id); return true; },
    admin_ban: ({ id, ban, reason }) => tx(() => {
      q('UPDATE users SET banned = ?, ban_reason = ? WHERE id = ?').run(ban ? 1 : 0, ban ? reason : null, id);
      if (ban) q('DELETE FROM sessions WHERE user_id = ?').run(id);
      return true;
    })
  };
  return {
    kind: 'sqlite',
    async call(name, args = {}) { const fn = ops[name]; if (!fn) throw new Error('operación desconocida: ' + name); return fn(args); },
    names: Object.keys(ops),
    close() { db.close(); }
  };
}
