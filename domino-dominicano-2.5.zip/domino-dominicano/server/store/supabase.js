// Dominó Dominicano · datos en Supabase (Postgres)
// No hace falta instalar nada: cada operación llama a una función de la base de datos por la API REST de Supabase:
//   POST {SUPABASE_URL}/rest/v1/rpc/dd_<operación>   cuerpo: { "p": { ...datos } }
// Las funciones dd_* y las tablas se crean con supabase/migrations/001_domino.sql.
// La clave secreta (sb_secret_… o la antigua service_role) SOLO va en el servidor (variables de entorno). Nunca en el navegador ni en GitHub.

const jwtBody = (k) => { try { return Buffer.from(k.split('.')[1] || '', 'base64url').toString('utf8'); } catch { return ''; } };

export function createSupabaseStore({ url, key, timeoutMs = 10000 }) {
  if (!url || !key) throw new Error('Faltan SUPABASE_URL o SUPABASE_SECRET_KEY');
  const base = url.replace(/\/+$/, '') + '/rest/v1/rpc/';
  // Claves nuevas (sb_secret_…): solo en el encabezado apikey. Claves antiguas (service_role, un JWT): apikey + Authorization.
  const headers = { 'Content-Type': 'application/json', Accept: 'application/json', apikey: key };
  if (!key.startsWith('sb_')) headers.Authorization = 'Bearer ' + key;
  if (key.startsWith('sb_publishable_') || /"role"\s*:\s*"anon"/.test(jwtBody(key))) throw new Error('Esa es la clave pública (anon/publishable). El servidor necesita la clave SECRETA (sb_secret_… o service_role).');

  async function call(name, args = {}) {
    if (!/^[a-z_]+$/.test(name)) throw new Error('operación inválida');
    const ctl = new AbortController(), timer = setTimeout(() => ctl.abort(), timeoutMs);
    let res;
    try { res = await fetch(base + 'dd_' + name, { method: 'POST', headers, body: JSON.stringify({ p: args }), signal: ctl.signal }); }
    catch (e) { throw new Error(`Supabase no responde (${name}): ${e.name === 'AbortError' ? 'tiempo agotado' : e.message}`); }
    finally { clearTimeout(timer); }
    const text = await res.text();
    if (!res.ok) {
      let msg = text; try { const j = JSON.parse(text); msg = [j.code, j.message, j.hint].filter(Boolean).join(' · '); } catch { /* texto */ }
      throw new Error(`Supabase ${res.status} en dd_${name}: ${msg}`);
    }
    return text ? JSON.parse(text) : null;
  }
  return { kind: 'supabase', call, close() {} };
}
