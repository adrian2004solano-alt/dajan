/* Dominó Dominicano · perfil (compartido)
 * Avatares dibujados con SVG (piel, pelo, sombrero, lentes, barba y fondo), temas de la mesa y validación de nombres.
 * Un avatar se guarda como un código corto, por ejemplo "s2.h3.c1.t0.g0.b1.k4".
 */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.DomProfile = factory();
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';

  const PARTS = {
    s: { label: 'Piel', n: 6 },
    h: { label: 'Pelo', n: 7, names: ['Calvo', 'Corto', 'Rizos', 'Largo', 'Afro', 'Moño', 'Fade'] },
    c: { label: 'Color de pelo', n: 6 },
    t: { label: 'Sombrero', n: 6, names: ['Ninguno', 'Gorra', 'Sombrero de guano', 'Boina', 'Pañuelo', 'Gorro'] },
    g: { label: 'Lentes', n: 3, names: ['Sin lentes', 'Lentes', 'Gafas de sol'] },
    b: { label: 'Barba', n: 4, names: ['Sin barba', 'Bigote', 'Chivo', 'Barba'] },
    k: { label: 'Fondo', n: 8 }
  };
  const ORDER = ['s', 'h', 'c', 't', 'g', 'b', 'k'];
  const SKIN = ['#f6d4b6', '#e9bc93', '#d49e70', '#b2784b', '#8c5835', '#603c24'];
  const HAIR = ['#1b1410', '#3d2617', '#6b4524', '#a46a30', '#d9b46b', '#a3a3a3'];
  const BG = ['#1f6b4e', '#25508f', '#a3322c', '#c4861a', '#5e3c96', '#1b7684', '#7d4527', '#2c3644'];
  const SHIRT = ['#f2ede0', '#f0cf73', '#2a2a2a', '#ffffff', '#d8e3ef', '#f1dac4', '#c3e2cd', '#e5d5f0'];
  const HAT = ['', '#c8102e', '#d9b56a', '#2b2b2b', '#1f4f9a', '#3a6b3a'];

  const RE = /^s[0-5]\.h[0-6]\.c[0-5]\.t[0-5]\.g[0-2]\.b[0-3]\.k[0-7]$/;
  const parse = (code) => {
    const o = {}; const ok = typeof code === 'string' && RE.test(code);
    (ok ? code : 's2.h1.c0.t0.g0.b0.k0').split('.').forEach((p) => { o[p[0]] = +p.slice(1); });
    return o;
  };
  const encode = (o) => ORDER.map((k) => k + (o[k] | 0)).join('.');
  const valid = (code) => typeof code === 'string' && RE.test(code);
  function random(rnd) {
    const r = rnd || Math.random, o = {};
    for (const k of ORDER) o[k] = Math.floor(r() * PARTS[k].n);
    if (r() < .5) o.t = 0; if (r() < .55) o.g = 0; if (r() < .45) o.b = 0;
    return encode(o);
  }

  // SVG de 64×64
  function svg(code, size) {
    const o = parse(code), sk = SKIN[o.s], hc = HAIR[o.c], bg = BG[o.k], sh = SHIRT[o.k], hat = HAT[o.t];
    const dark = (hex, f) => { const n = parseInt(hex.slice(1), 16); const r = Math.round(((n >> 16) & 255) * f), g = Math.round(((n >> 8) & 255) * f), b = Math.round((n & 255) * f); return '#' + ((1 << 24) | (r << 16) | (g << 8) | b).toString(16).slice(1); };
    const p = [];
    p.push(`<circle cx="32" cy="32" r="32" fill="${bg}"/>`);
    p.push(`<circle cx="32" cy="32" r="31" fill="none" stroke="#ffffff" stroke-opacity=".14" stroke-width="2"/>`);
    // pelo largo detrás de la cabeza
    if (o.h === 3) p.push(`<path d="M17 30 Q16 50 22 58 L42 58 Q48 50 47 30 Z" fill="${hc}"/>`);
    if (o.h === 4) p.push(`<circle cx="32" cy="25" r="18" fill="${hc}"/>`);
    // hombros y cuello
    p.push(`<path d="M10 64 Q12 47 32 45 Q52 47 54 64 Z" fill="${sh}"/>`);
    p.push(`<path d="M26 44 L32 52 L38 44" fill="none" stroke="${dark(sh, .8)}" stroke-width="1.6"/>`);
    p.push(`<rect x="27" y="37" width="10" height="9" rx="3" fill="${dark(sk, .9)}"/>`);
    // orejas y cara
    p.push(`<ellipse cx="18.5" cy="29" rx="3" ry="4" fill="${dark(sk, .93)}"/><ellipse cx="45.5" cy="29" rx="3" ry="4" fill="${dark(sk, .93)}"/>`);
    p.push(`<ellipse cx="32" cy="28" rx="13.5" ry="15" fill="${sk}"/>`);
    // pelo
    if (o.h === 1) p.push(`<path d="M18.5 26 Q18 12 32 12 Q46 12 45.5 26 Q42 18 32 18.5 Q22 18 18.5 26 Z" fill="${hc}"/>`);
    if (o.h === 2) { let c = ''; for (const [x, y] of [[20, 20], [24, 15], [30, 13], [36, 13], [42, 16], [45, 22], [19, 26], [27, 16], [39, 17]]) c += `<circle cx="${x}" cy="${y}" r="4.6" fill="${hc}"/>`; p.push(c); }
    if (o.h === 3) p.push(`<path d="M18.5 30 Q17 11 32 11 Q47 11 45.5 30 Q44 19 36 17 Q30 22 21 21 Q19 25 18.5 30 Z" fill="${hc}"/>`);
    if (o.h === 4) p.push(`<path d="M19 24 Q24 17 32 18 Q40 17 45 24 Q42 15 32 14 Q22 15 19 24 Z" fill="${dark(hc, .85)}"/>`);
    if (o.h === 5) p.push(`<circle cx="32" cy="9.5" r="6" fill="${hc}"/><path d="M18.5 26 Q18 13 32 13 Q46 13 45.5 26 Q41 18 32 18 Q23 18 18.5 26 Z" fill="${hc}"/>`);
    if (o.h === 6) p.push(`<path d="M20 20 Q22 12 32 12 Q42 12 44 20 Q38 16 32 16 Q26 16 20 20 Z" fill="${hc}"/><path d="M18.6 27 Q18.5 21 20 20 L20.5 27 Z M45.4 27 Q45.5 21 44 20 L43.5 27 Z" fill="${hc}" opacity=".55"/>`);
    // cejas, ojos, nariz y boca
    p.push(`<path d="M23.5 23.5 Q26.5 22 29 23.3 M35 23.3 Q37.5 22 40.5 23.5" stroke="${o.h === 0 ? dark(sk, .55) : hc}" stroke-width="1.7" fill="none" stroke-linecap="round"/>`);
    p.push(`<ellipse cx="26.5" cy="28" rx="1.9" ry="2.2" fill="#1d1712"/><ellipse cx="37.5" cy="28" rx="1.9" ry="2.2" fill="#1d1712"/>`);
    p.push(`<circle cx="27.1" cy="27.3" r=".6" fill="#fff"/><circle cx="38.1" cy="27.3" r=".6" fill="#fff"/>`);
    p.push(`<path d="M32 30 Q30.6 34 32.6 34.4" stroke="${dark(sk, .72)}" stroke-width="1.3" fill="none" stroke-linecap="round"/>`);
    // barba
    if (o.b === 3) p.push(`<path d="M18.8 29 Q19 44 32 44.5 Q45 44 45.2 29 Q43 38 38 38.5 Q32 36.5 26 38.5 Q21 38 18.8 29 Z" fill="${hc}"/>`);
    if (o.b === 2) p.push(`<path d="M28.5 39.2 Q32 45.5 35.5 39.2 Q32 40.6 28.5 39.2 Z" fill="${hc}"/>`);
    if (o.b >= 1) p.push(`<path d="M26.5 36.4 Q32 33.4 37.5 36.4 Q32 35.2 26.5 36.4 Z" fill="${hc}" stroke="${hc}" stroke-width="1.6" stroke-linejoin="round"/>`);
    p.push(`<path d="M28 ${o.b >= 1 ? 38.6 : 37.2} Q32 ${o.b >= 1 ? 40.6 : 39.8} 36 ${o.b >= 1 ? 38.6 : 37.2}" stroke="#6b2f22" stroke-width="1.5" fill="none" stroke-linecap="round"/>`);
    // lentes
    if (o.g === 1) p.push(`<g fill="none" stroke="#2b2b2b" stroke-width="1.4"><circle cx="26.5" cy="28" r="4.3"/><circle cx="37.5" cy="28" r="4.3"/><path d="M30.8 28 L33.2 28 M22.2 27.3 L18.8 26.4 M41.8 27.3 L45.2 26.4"/></g>`);
    if (o.g === 2) p.push(`<g><rect x="21.5" y="24.6" width="9.6" height="6.8" rx="2.6" fill="#141414"/><rect x="32.9" y="24.6" width="9.6" height="6.8" rx="2.6" fill="#141414"/><path d="M31 27 L33 27 M21.6 26.6 L18.8 25.8 M42.4 26.6 L45.2 25.8" stroke="#141414" stroke-width="1.4"/><path d="M23 26.2 L26 26.2" stroke="#fff" stroke-opacity=".45" stroke-width="1"/></g>`);
    // sombreros
    if (o.t === 1) p.push(`<path d="M18 22 Q18 9.5 32 9.5 Q46 9.5 46 22 Z" fill="${hat}"/><path d="M32 22 Q43 20 52 23.5 Q46 25.5 32 23.6 Z" fill="${dark(hat, .75)}"/><circle cx="32" cy="10.2" r="1.6" fill="${dark(hat, .7)}"/><path d="M25 21.5 L25.5 12" stroke="${dark(hat, .82)}" stroke-width=".9"/>`);
    if (o.t === 2) p.push(`<ellipse cx="32" cy="19.5" rx="21" ry="5" fill="${dark(hat, .86)}"/><path d="M21 19.5 Q21 7 32 7 Q43 7 43 19.5 Z" fill="${hat}"/><path d="M21.4 16.5 Q32 19 42.6 16.5 L42.8 18.6 Q32 21 21.2 18.6 Z" fill="#7a2a1c"/><path d="M14 20 Q32 25 50 20" stroke="${dark(hat, .7)}" stroke-width=".8" fill="none"/>`);
    if (o.t === 3) p.push(`<path d="M17.5 21 Q16 11 30 10 Q46 9 47 19 Q40 16 31 16.6 Q22 17 17.5 21 Z" fill="${hat}"/><circle cx="33" cy="9.6" r="1.5" fill="${hat}"/>`);
    if (o.t === 4) p.push(`<path d="M18.4 23 Q18 10.5 32 10.5 Q46 10.5 45.6 23 Q40 18.5 32 18.5 Q24 18.5 18.4 23 Z" fill="${hat}"/><path d="M44 19 L50.5 23 L46.5 26 Z" fill="${dark(hat, .8)}"/><g fill="#ffffff" opacity=".7"><circle cx="26" cy="15" r="1"/><circle cx="32" cy="13.4" r="1"/><circle cx="38" cy="15" r="1"/></g>`);
    if (o.t === 5) p.push(`<path d="M18.4 22.5 Q18 8 32 8 Q46 8 45.6 22.5 Z" fill="${hat}"/><rect x="17.6" y="19" width="28.8" height="5" rx="2.4" fill="${dark(hat, .78)}"/><circle cx="32" cy="7.2" r="2.8" fill="${dark(hat, .85)}"/>`);
    const s = size || 64;
    return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64" width="${s}" height="${s}"><defs><clipPath id="a"><circle cx="32" cy="32" r="32"/></clipPath></defs><g clip-path="url(#a)">${p.join('')}</g></svg>`;
  }
  const dataUri = (code, size) => 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(svg(code, size));

  // ---- temas de la mesa ----
  const THEMES = {
    scene: { patio: 'Patio dominicano', ciudad: 'Azotea en la ciudad', clasico: 'Clásico' },
    felt: { bandera: 'Bandera dominicana', verde: 'Paño verde', azul: 'Paño azul', vino: 'Paño vino' },
    wood: { nogal: 'Nogal', caoba: 'Caoba', roble: 'Roble claro', ebano: 'Ébano' },
    tiles: { marfil: 'Marfil', perla: 'Blanco perla', negro: 'Negras' },
    pips: { clasico: 'Puntos clásicos', colores: 'Puntos de colores' }
  };
  const DEFAULT_PREFS = { scene: 'patio', felt: 'bandera', wood: 'nogal', tiles: 'marfil', pips: 'clasico' };
  function cleanPrefs(p) {
    const o = Object.assign({}, DEFAULT_PREFS);
    if (p && typeof p === 'object') for (const k of Object.keys(DEFAULT_PREFS)) if (THEMES[k][p[k]]) o[k] = p[k];
    return o;
  }

  // ---- nombres ----
  function checkName(n) {
    if (typeof n !== 'string') return 'Escribe un nombre';
    n = n.trim().replace(/\s+/g, ' ');
    if (n.length < 3) return 'El nombre debe tener al menos 3 letras';
    if (n.length > 16) return 'El nombre puede tener hasta 16 caracteres';
    if (!/^[A-Za-zÁÉÍÓÚÜÑáéíóúüñ0-9 _.\-]+$/.test(n)) return 'Usa solo letras, números, espacio, punto, guion o guion bajo';
    if (/^(bot|soporte|admin|sistema)\b/i.test(n)) return 'Ese nombre está reservado';
    return null;
  }

  return { PARTS, ORDER, SKIN, HAIR, BG, parse, encode, valid, random, svg, dataUri, THEMES, DEFAULT_PREFS, cleanPrefs, checkName };
});
