// Simulador mínimo de la API de Supabase (solo /rest/v1/rpc/*) sobre un Postgres local, para probar el servidor
// con la MISMA migración que se corre en Supabase, sin tener una cuenta.
// Requiere Postgres y psql instalados. Uso:
//   PGHOST=/tmp/pgsock PGPORT=5433 PGUSER=postgres node tests/supabase-sim.mjs      (escucha en :5434, clave "clave-sim")
// y en otra terminal:
//   SUPABASE_URL=http://localhost:5434 SUPABASE_SECRET_KEY=clave-sim node tests/server.test.mjs
import { createServer } from 'node:http';
import { spawn, spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { randomBytes } from 'node:crypto';

const root = fileURLToPath(new URL('..', import.meta.url));
const PORT = +(process.env.SIM_PORT || 5434), KEY = process.env.SIM_KEY || 'clave-sim', DB = process.env.SIM_DB || 'domino_sim';
const psql = (args, input) => spawnSync('psql', ['-v', 'ON_ERROR_STOP=1', '-q', ...args], { input, encoding: 'utf8' });

// base de datos limpia con roles como los de Supabase + la migración
for (const r of [psql(['-d', 'postgres', '-c', `drop database if exists ${DB} with (force)`]), psql(['-d', 'postgres', '-c', `create database ${DB}`])]) if (r.status) { console.error(r.stderr); process.exit(1); }
psql(['-d', DB, '-c', "do $$ begin create role anon nologin; exception when duplicate_object then null; end $$; do $$ begin create role authenticated nologin; exception when duplicate_object then null; end $$; do $$ begin create role service_role nologin bypassrls; exception when duplicate_object then null; end $$;"]);
const mig = psql(['-d', DB, '-f', root + 'supabase/migrations/001_domino.sql']);
if (mig.status) { console.error(mig.stderr); process.exit(1); }

// una sesión de psql abierta, con el rol service_role (como el servidor en Supabase)
const sh = spawn('sh', ['-c', `psql -d ${DB} -At -q -v ON_ERROR_STOP=0 2>&1`], { stdio: ['pipe', 'pipe', 'inherit'] });
sh.stdin.write('set role service_role;\n');
let buf = '', queue = [], busy = null;
sh.stdout.on('data', (d) => {
  buf += d;
  let i;
  while (busy && (i = buf.indexOf(busy.mark + '\n')) >= 0) {
    const out = buf.slice(0, i); buf = buf.slice(i + busy.mark.length + 1);
    const b = busy; busy = null; b.done(out); next();
  }
});
function next() { if (busy || !queue.length) return; busy = queue.shift(); sh.stdin.write(busy.sql + `\n\\echo ${busy.mark}\n`); }
function run(fn, p) {
  return new Promise((done) => {
    const tag = 'q' + randomBytes(6).toString('hex'), json = JSON.stringify(p ?? {});
    queue.push({ sql: `select public.${fn}($${tag}$${json}$${tag}$::jsonb);`, mark: '__FIN_' + tag + '__', done });
    next();
  });
}

createServer((req, res) => {
  const m = req.url.match(/^\/rest\/v1\/rpc\/([a-z_]+)$/);
  const reply = (st, body) => { res.writeHead(st, { 'Content-Type': 'application/json' }); res.end(body); };
  if (req.method !== 'POST' || !m) return reply(404, '{"message":"no existe"}');
  if (req.headers.apikey !== KEY || (req.headers.authorization && req.headers.authorization !== 'Bearer ' + KEY)) return reply(401, '{"message":"Invalid API key"}');
  let body = ''; req.on('data', (c) => { body += c; });
  req.on('end', async () => {
    let p; try { p = JSON.parse(body || '{}').p; } catch { return reply(400, '{"message":"JSON inválido"}'); }
    const out = (await run(m[1], p)).trim();
    if (/^(ERROR|psql:)/m.test(out)) return reply(400, JSON.stringify({ code: 'P0001', message: out }));
    reply(200, out === '' ? 'null' : out);
  });
}).listen(PORT, () => console.log(`Simulador de Supabase en http://localhost:${PORT} (base ${DB})`));
