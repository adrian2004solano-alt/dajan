# Lanzamiento y promoción

## Antes de anunciarlo

- [ ] `npm test` pasa sin fallas.
- [ ] Probado en un Android y un iPhone reales (horizontal y vertical), con y sin sonido.
- [ ] Dominio propio conectado y `npm run domain -- https://tudominio.com` aplicado.
- [ ] `ADMIN_KEY` configurada y panel `/admin` probado.
- [ ] Volumen montado en `/data` (si no, se pierden cuentas y monedas en cada despliegue).
- [ ] Nombre del titular revisado en `LICENSE`.
- [ ] Enlace probado en WhatsApp (debe salir la imagen de la mesa con el título). Si no se actualiza la imagen, prueba con el [depurador de Facebook](https://developers.facebook.com/tools/debug/).
- [ ] Sitemap enviado en Google Search Console.
- [ ] Instalación probada: en Android, menú → "Instalar app"; en iPhone, Compartir → "Agregar a inicio".

## Material listo para usar

- `assets/og/og-image.jpg` — imagen para publicaciones y enlaces (1200×630).
- `assets/screenshots/mesa-1280x720.jpg` — captura horizontal.
- `assets/screenshots/telefono-780x1688.jpg` — captura de teléfono (sirve para historias/estados).
- `assets/icons/icon-512.png` — logo.

## Ideas para promocionarlo

- Grabar un video corto de una mano con capicúa o pase corrido para TikTok, Reels y estados de WhatsApp.
- Compartirlo en grupos de dominó y de dominicanos en el exterior (Facebook, WhatsApp).
- Pedir a jugadores conocidos que lo prueben y opinen antes del anuncio grande.

## Lo que conviene agregar después

- **Salas privadas con código** para jugar con amigos (el servidor ya lo permite técnicamente).
- **Nombre y avatar del jugador**, niveles de dificultad de los rivales, estadísticas personales.
- **Publicarlo en Google Play** como app (con la PWA se puede empaquetar usando Bubblewrap / PWABuilder).
