# Conectar Supabase (base de datos en producción)

El juego ya está preparado para Supabase. **No hay que instalar nada ni cambiar código**: solo crear la base de datos
con un archivo SQL y darle al servidor dos variables.

## Cómo encaja todo

```
 Navegador (index.html)  ──HTTPS + WebSocket──►  Servidor Node.js (server/)  ──HTTPS──►  Supabase (Postgres)
   lobby, mesa, salas                              emparejamiento, salas,                   cuentas, monedas,
                                                   mesas EN VIVO (memoria)                  historial, chat, soporte
```

- El **navegador nunca habla con Supabase**. Habla solo con nuestro servidor. Por eso no se usa la clave pública
  (anon/publishable) en ningún lado y no hacen falta políticas RLS públicas.
- El **servidor** habla con Supabase usando la **clave secreta** (`sb_secret_…` o la antigua `service_role`), llamando a
  funciones de la base de datos: `POST https://<proyecto>.supabase.co/rest/v1/rpc/dd_<operación>` con `{"p": {...}}`.
  Está en `server/store/supabase.js` (sin librerías).
- Lo **en vivo** (quién está conectado, la cola para buscar mesa, las salas privadas y las partidas en curso) vive en
  la memoria del servidor: es instantáneo y no necesita base de datos. Por eso el servidor corre como **una sola
  instancia** (no lo escales a varias réplicas).
- **Supabase no puede alojar el servidor** (las Edge Functions no mantienen WebSockets abiertos). El servidor va en
  Railway, Render, Fly.io o un VPS. Supabase solo guarda los datos.

## Pasos

1. **Crear el proyecto** en [supabase.com](https://supabase.com) → New project. Región: la más cercana a donde estará el
   servidor (por ejemplo, `East US` si el servidor está en Railway US East).
2. **Crear las tablas y funciones**: Supabase → **SQL Editor** → New query → pega TODO
   [`supabase/migrations/001_domino.sql`](../supabase/migrations/001_domino.sql) → **Run**.
   - Se puede correr otra vez sin romper nada (crea lo que falte y actualiza las funciones).
   - Con la CLI de Supabase también sirve: `supabase link --project-ref <ref>` y `supabase db push`.
3. **Copiar los datos de conexión**: Supabase → **Project Settings → API Keys** (y **Data API** para la URL):
   - `SUPABASE_URL` = `https://<ref>.supabase.co` (sin `/rest/v1` al final).
   - `SUPABASE_SECRET_KEY` = una **secret key** (`sb_secret_…`). Si el proyecto solo muestra las claves antiguas, usa la
     `service_role` (también funciona; en ese caso puedes ponerla en `SUPABASE_SERVICE_ROLE_KEY`).
   - ⚠️ La clave secreta da acceso total. Va **solo** en las variables del servidor. Nunca en el código, en GitHub, en
     el navegador ni en un chat.
4. **Revisar la conexión** desde tu computadora (opcional pero recomendado):
   ```bash
   SUPABASE_URL=https://<ref>.supabase.co SUPABASE_SECRET_KEY=sb_secret_… SUPABASE_ANON_KEY=<clave pública> npm run check:supabase
   ```
   Tiene que terminar con «Todo listo». Si dice que falta una función, corre otra vez el paso 2 y espera un minuto.
5. **Publicar el servidor** (ver [SERVIDOR.md](SERVIDOR.md)) con estas variables:
   | Variable | Valor |
   |---|---|
   | `SUPABASE_URL` | `https://<ref>.supabase.co` |
   | `SUPABASE_SECRET_KEY` | `sb_secret_…` (o `service_role`) |
   | `ADMIN_KEY` | una clave larga inventada por ti (panel `/admin`) |
   | `RESEND_API_KEY` y `MAIL_FROM` | para enviar el código de registro por correo (ver `.env.example`) |
   | `ALLOWED_ORIGINS` | solo si la página está en otro dominio que el servidor, ej. `https://tu-sitio.vercel.app` |

   Al arrancar, el registro del servidor dice `datos: Supabase`. Y `https://tu-servidor/api/health` responde
   `{"ok":true,"db":"supabase","dbOk":true,…}`.

## Qué se guarda (tablas)

| Tabla | Para qué |
|---|---|
| `users` | cuentas (invitado o con contraseña), monedas, avatar, personalización, estadísticas, sanciones |
| `sessions` | sesiones abiertas (solo el hash del token) |
| `ledger` | cada movimiento de monedas (bienvenida, bonos, apuesta, premio, devolución, ajuste) |
| `matches` | partidas: activa / terminada / anulada, quién pagó, resultado y código de sala si vino de una invitación |
| `chat` y `reports` | chat del lobby y reportes |
| `tickets` y `ticket_msgs` | servicio al cliente |

Todas con **RLS activado y sin políticas**: con la clave pública no se puede leer ni escribir nada. Las funciones
`dd_*` solo las puede ejecutar el rol `service_role` (el servidor).

## Probar sin cuenta de Supabase

`tests/supabase-sim.mjs` imita la API de Supabase sobre un Postgres local y corre la misma migración:

```bash
PGHOST=… PGUSER=postgres node tests/supabase-sim.mjs            # terminal 1
SUPABASE_URL=http://localhost:5434 SUPABASE_SECRET_KEY=clave-sim npm run test:server   # terminal 2
```

## Problemas comunes

| Síntoma | Causa y arreglo |
|---|---|
| `Supabase 404 … Could not find the function public.dd_…` | No se corrió la migración, o la API todavía no la ve: corre el paso 2 y espera ~1 min (o ejecuta `notify pgrst, 'reload schema';`). |
| `Supabase 401 … Invalid API key` | Clave mal copiada o es la pública. Usa la **secreta**. |
| `permission denied for function dd_…` | Estás usando la clave pública. Usa la secreta. |
| El servidor no arranca: «No se pudo revisar partidas interrumpidas» | No llega a Supabase: revisa `SUPABASE_URL` (sin `/rest/v1`) y que el proyecto no esté en pausa (los proyectos gratis se pausan tras días sin uso). |
| Las monedas se ven, pero tarda en entrar | Servidor y Supabase en regiones lejanas. Ponlos en la misma región. |
