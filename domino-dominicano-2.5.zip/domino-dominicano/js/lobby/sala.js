// Dominó Dominicano · salas privadas: crear una sala, invitar por enlace o código, elegir asiento y empezar.
// El enlace de invitación es  https://tu-sitio/?sala=CODIGO  — al abrirlo, el juego entra solo a la sala.
const SALA={pending:null};
(function(){
 const fromUrl=new URLSearchParams(location.search).get('sala')||(location.hash.match(/sala=([A-Za-z0-9-]+)/)||[])[1];
 if(fromUrl){SALA.pending=fromUrl.toUpperCase().replace(/[^A-Z0-9]/g,'').slice(0,8);try{history.replaceState(null,'',location.pathname)}catch(e){}}
})();
const salaLink=code=>location.origin+'/?sala='+code;
const prettyCode=c=>c.length===6?c.slice(0,3)+'-'+c.slice(3):c;
const modeName=m=>({duelo:'1 vs 1',trio:'Tríos',parejas:'Parejas'})[m]||'Parejas';
function salaShareText(s){return'¡Vente a jugar dominó conmigo! Sala '+prettyCode(s.code)+' ('+modeName(s.mode)+' · a '+s.target+' · '+(s.stake?money(s.stake):'gratis')+'): '+salaLink(s.code)}
async function salaShare(s){const text=salaShareText(s);
 if(navigator.share){try{await navigator.share({title:'Dominó Dominicano',text:'¡Vente a jugar dominó conmigo! Sala '+prettyCode(s.code),url:salaLink(s.code)});return}catch(e){if(e&&e.name==='AbortError')return}}
 copyText(text,'Enlace copiado. Pégalo en WhatsApp o donde quieras.')}
async function copyText(t,msg){try{await navigator.clipboard.writeText(t);toastL(msg||'Copiado.','good')}catch(e){
 const ta=h('textarea',{style:'position:fixed;opacity:0'},t);document.body.append(ta);ta.select();try{document.execCommand('copy');toastL(msg||'Copiado.','good')}catch(_){toastL('No se pudo copiar. Código: '+t,'bad')}ta.remove()}}

function joinSala(code){code=String(code||'').toUpperCase().replace(/[^A-Z0-9]/g,'');
 if(code.length<4)return toastL('Escribe el código de la sala (6 letras y números).','bad');
 if(!LOBBY.online){SALA.pending=code;return toastL('Conectando… entrarás a la sala cuando haya conexión.')}
 NET.send({t:'sala_unirse',code})}
$('#salaNew').onclick=()=>{if(!LOBBY.online)return toastL('Para crear una sala necesitas conexión con el servidor.','bad');
 if(!LOBBY.free&&!LOBBY.me.registered)return toastL('Para jugar con dinero regístrate con tu correo en Perfil. O elige Gratis.','bad');
 if(!LOBBY.free&&LOBBY.me.coins<LOBBY.stake)return toastL('No te alcanza el saldo para esa mesa.','bad');
 NET.send({t:'sala_crear',mode:LOBBY.mode,stake:LOBBY.free?0:LOBBY.stake,target:LOBBY.target})};
$('#salaJoinForm').onsubmit=e=>{e.preventDefault();joinSala($('#salaCode').value)};

// ---- la sala de espera ----
function renderSala(){const s=LOBBY.sala,box=$('#salaPanel');
 $('#playPanel').hidden=!!s;box.hidden=!s;if(!s){$('#smsgs').innerHTML='';return}
 const me=LOBBY.me&&LOBBY.me.id,host=s.host===me,mine=s.seats.findIndex(x=>x&&x.uid===me),humans=s.seats.filter(Boolean).length;
 $('#salaMeta').textContent=modeName(s.mode)+' · '+(s.target===100?'rápida, a 100':'normal, a 200')+' · '+(s.stake?money(s.stake):'gratis');
 $('#salaCodeBig').textContent=prettyCode(s.code);
 $('#salaWa').href='https://wa.me/?text='+encodeURIComponent(salaShareText(s));
 // asientos: en parejas, 0 y 2 van juntos contra 1 y 3
 const seats=$('#salaSeats');seats.innerHTML='';seats.className='sala-seats n'+s.n;
 s.seats.forEach((p,i)=>{const team=s.n===4?(i%2===0?'a':'b'):['a','b','c'][i],label=s.n===4?(i%2===0?'Pareja A':'Pareja B'):'Jugador '+(i+1);
  const card=h('div',{class:'seat team-'+team+(p&&p.uid===me?' me':'')+' pos'+i});
  if(p){card.append(h('img',{src:DomProfile.dataUri(p.avatar||'s0.h0.c0.t0.g0.b0.k0',64),alt:''}),
    h('b',{},p.name+(p.uid===me?' (tú)':'')),h('small',{},(p.uid===s.host?'Anfitrión · ':'')+(p.online?label:'desconectado…')));
   if(host&&p.uid!==me&&s.state==='espera')card.append(h('button',{class:'kick',title:'Sacar de la sala','aria-label':'Sacar a '+p.name,onclick:()=>dialog('¿Sacar a '+p.name+'?','No podrá volver a entrar a esta sala.',[['Cancelar','ghost'],['Sacar','gold',()=>NET.send({t:'sala_expulsar',uid:p.uid})]])},'✕'))}
  else{card.classList.add('empty');card.append(h('span',{class:'empty-av'},'?'),h('b',{},'Asiento libre'),h('small',{},label+(s.stake?' · esperando':' · BOT si nadie entra')));
   if(mine>=0&&s.state==='espera')card.append(h('button',{class:'btn ghost sit',onclick:()=>NET.send({t:'sala_asiento',seat:i})},'Sentarme aquí'))}
  seats.append(card)});
 // controles del anfitrión
 const ctl=$('#salaHost');ctl.innerHTML='';
 if(s.state==='jugando')ctl.append(h('p',{class:'fine'},'La partida está en juego…'));
 else if(host){
  const mode=h('select',{'aria-label':'Modo',onchange:e=>NET.send({t:'sala_config',mode:e.target.value})},h('option',{value:'parejas'},'Parejas (2 vs 2)'),h('option',{value:'duelo'},'1 vs 1'),h('option',{value:'trio'},'Tríos (3 solos)'));mode.value=s.mode;
  const len=h('select',{'aria-label':'Partida',onchange:e=>NET.send({t:'sala_config',target:+e.target.value})},h('option',{value:100},'Rápida (a 100)'),h('option',{value:200},'Normal (a 200)'));len.value=s.target;
  const stake=h('select',{'aria-label':'Monto',onchange:e=>NET.send({t:'sala_config',stake:+e.target.value})},h('option',{value:0},'Gratis'),...LOBBY.stakes.map(v=>h('option',{value:v},money(v))));stake.value=s.stake;
  ctl.append(h('div',{class:'sala-cfg'},h('label',{},'Modo',mode),h('label',{},'Partida',len),h('label',{},'Monto',stake)),
   h('button',{class:'btn gold big',disabled:humans<2||(s.stake&&humans<s.n)?'':null,onclick:()=>NET.send({t:'sala_iniciar'})},humans<2?'Esperando a tus invitados…':'Empezar partida'),
   h('p',{class:'fine'},humans<s.n?(s.stake?'Con dinero se juega solo entre personas: faltan '+(s.n-humans)+'.':'Los asientos vacíos se llenan con jugadores de la computadora (BOT).'):'¡Mesa completa!'))}
 else ctl.append(h('p',{class:'sala-wait'},h('span',{class:'spinner small'}),'Esperando a que '+((s.seats.find(x=>x&&x.uid===s.host)||{}).name||'el anfitrión')+' empiece la partida…'));
}
$('#salaCopy').onclick=()=>LOBBY.sala&&copyText(LOBBY.sala.code,'Código copiado: '+prettyCode(LOBBY.sala.code));
$('#salaShare').onclick=()=>LOBBY.sala&&salaShare(LOBBY.sala);
$('#salaLeave').onclick=()=>dialog('¿Salir de la sala?','Puedes volver a entrar con el mismo código mientras la sala siga abierta.',[['Quedarme','ghost'],['Salir','gold',()=>{NET.send({t:'sala_salir'});LOBBY.sala=null;renderSala()}]]);
$('#schatForm').onsubmit=e=>{e.preventDefault();const i=$('#schatIn');if(i.value.trim())NET.send({t:'chat',scope:'sala',text:i.value});i.value=''};

NET.on('sala',m=>{const was=LOBBY.sala;LOBBY.sala=m.sala;
 if(m.sala&&!was){showView('jugar');$('#searching').hidden=true;$('#lobby').scrollTop=0}
 if(!m.sala&&m.msg)toastL(m.msg,'bad');
 renderSala()});
NET.on('schat',m=>{const box=$('#smsgs');box.append(h('li',{},h('b',{},(LOBBY.me&&m.uid===LOBBY.me.id?'Tú':m.name)+': '),m.text));while(box.children.length>60)box.firstChild.remove();box.scrollTop=box.scrollHeight});
NET.on('welcome',()=>{if(SALA.pending){const c=SALA.pending;SALA.pending=null;toastL('Entrando a la sala '+prettyCode(c)+'…');NET.send({t:'sala_unirse',code:c})}});
NET.on('status',on=>{if(!on&&LOBBY.sala){LOBBY.sala=null;renderSala()}});
