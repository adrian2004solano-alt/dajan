// Dominó Dominicano · core/screen.js
// Pantalla: se adapta a móvil y escritorio, respeta las zonas seguras y gira la mesa si el teléfono está vertical.
// Nota: todos los archivos de js/core, js/game y js/render comparten el mismo ámbito global y se cargan en el orden
// definido en js/app/loader.js (no cambies ese orden sin probar).
// ---- pantalla: se adapta a móvil (horizontal) y gira la mesa si el teléfono está vertical ----
const stage=document.getElementById('stage'),probe=document.getElementById('probe'),hint=document.getElementById('hint');
let SW=VW,SH=VH,portrait=false,SL=0,ST=0,SR=0,IW=0,hintDone=false;
function resize(){
 dpr=Math.min(devicePixelRatio||1,2.5);
 const iw=innerWidth,ih=innerHeight,cs=getComputedStyle(probe);
 const st=parseFloat(cs.paddingTop)||0,sr=parseFloat(cs.paddingRight)||0,sb=parseFloat(cs.paddingBottom)||0,sl=parseFloat(cs.paddingLeft)||0;
 portrait=ih>iw;IW=iw;SL=sl;ST=st;SR=sr;
 lastPortrait=portrait;
 if(portrait){SW=ih-st-sb;SH=iw-sl-sr;stage.style.left=(iw-sr)+'px';stage.style.top=st+'px';stage.style.transform='rotate(90deg)'}
 else{SW=iw-sl-sr;SH=ih-st-sb;stage.style.left=sl+'px';stage.style.top=st+'px';stage.style.transform='none'}
 stage.style.width=SW+'px';stage.style.height=SH+'px';
 cv.width=Math.round(SW*dpr);cv.height=Math.round(SH*dpr);
 k=Math.min(SW/VW,SH/VH);ox=(SW-VW*k)/2;oy=(SH-VH*k)/2;KK=dpr*k;DX=dpr*ox;DY=dpr*oy;
 if(portrait&&!hintDone){hintDone=true;hint.style.display='block';setTimeout(()=>hint.style.display='none',7000)}
 else if(!portrait)hint.style.display='none'}
let lastPortrait=null;addEventListener('resize',resize);addEventListener('orientationchange',()=>setTimeout(resize,250));resize();
addEventListener('contextmenu',e=>e.preventDefault());
const rnd=(a,b)=>a+Math.random()*(b-a),clamp=(v,a=0,b=1)=>Math.max(a,Math.min(b,v)),ease=u=>1-Math.pow(1-u,3),lerp=(a,b,u)=>a+(b-a)*u;
const angd=(a,b)=>{let d=(b-a)%(2*Math.PI);if(d>Math.PI)d-=2*Math.PI;if(d<-Math.PI)d+=2*Math.PI;return d};
