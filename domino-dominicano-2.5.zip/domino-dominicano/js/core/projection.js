// Dominó Dominicano · core/projection.js
// Perspectiva de la mesa (lejos más angosto) y transformaciones de dibujo.
// Nota: todos los archivos de js/core, js/game y js/render comparten el mismo ámbito global y se cargan en el orden
// definido en js/app/loader.js (no cambies ese orden sin probar).
// ---- proyección de la mesa (perspectiva: lejos más angosto) ----
const proj=(x,y)=>{const s=1/(1+Q*(1-y/BH));return{x:CX+x*s,y:YH+CC*s,s}};
const inv=(sx,sy)=>{const s=(sy-YH)/CC,t=1-(1/s-1)/Q;return{x:(sx-CX)/s,y:t*BH}};
// SM: transformación afín lógica con la rotación/escala global (inclinación de la mesa al barajar)
let SHX=0,SHY=0; // sacudida de la mesa (capicúa)
function SM(a,b,c2,d,e,f){const co=Math.cos(ROT)*SCL,si=Math.sin(ROT)*SCL,px=CX,py=330;
 const tx=e-px,ty=f-py;c.setTransform(KK*(co*a-si*b),KK*(si*a+co*b),KK*(co*c2-si*d),KK*(si*c2+co*d),KK*(co*tx-si*ty+px+SHX)+DX,KK*(si*tx+co*ty+py+SHY)+DY)}
const T0=()=>c.setTransform(KK,0,0,KK,DX,DY),T2=()=>SM(1,0,0,1,0,0);
function TB(x,y,a,lift=0,sc=1){const P=proj(x,y),P1=proj(x+Math.cos(a),y+Math.sin(a)),P2=proj(x-Math.sin(a),y+Math.cos(a));
 SM((P1.x-P.x)*sc,(P1.y-P.y)*sc,(P2.x-P.x)*sc,(P2.y-P.y)*sc,P.x,P.y-lift)}
function TS(x,y,a,sc=1){const co=Math.cos(a)*sc,si=Math.sin(a)*sc;SM(co,si,-si,co,x,y)}
