// Dominó Dominicano · render/theme.js
// Personalización de la mesa: paño, madera, color de las fichas y de los puntos.
// Nota: todos los archivos de js/core, js/game y js/render comparten el mismo ámbito global y se cargan en el orden
// definido en js/app/loader.js (no cambies ese orden sin probar).
const WOODS={
 nogal:{body:[[168,104,54],[60,30,11]],rack:[[138,76,38],[38,17,6]]},
 caoba:{body:[[158,66,40],[52,15,7]],rack:[[128,50,30],[34,9,4]]},
 roble:{body:[[212,166,108],[122,82,42]],rack:[[180,128,76],[88,54,24]]},
 ebano:{body:[[82,58,44],[16,11,8]],rack:[[66,46,35],[10,7,5]]}
};
const FELTS={
 verde:{base:'#1f5e3b',hi:'#2f7a4f',lo:'#0f3a22'},
 azul:{base:'#1d3f73',hi:'#2c5a9a',lo:'#0e2246'},
 vino:{base:'#5e1a24',hi:'#7d2a35',lo:'#36090f'}
};
const PIPCOL={1:'#d62828',2:'#1d6fd1',3:'#2b9348',4:'#e8890c',5:'#7b2cbf',6:'#0b7285'};
const TILESETS={
 marfil:{face:['#fffdf4','#f6f1e1','#e6e1cf'],back:['#f7f2e3','#ddd5bf'],edge:'#a29d86',edgeUp:'#a9a48e',edgeBack:'#b5b09a',edgeStroke:'#6e6955',stroke:'#9d9780',outline:'#7d7862',
  line:'#b8b29c',lineHand:'#a39c84',hi:'rgba(255,255,255,.85)',pip:'#1b1b1b',rim:'rgba(255,255,255,.9)',pipIn:'#3a352d',rgb:[[250,244,226],[248,242,225],[240,232,212],[214,203,178]],under:'#9d967e',tex:1,dark:false},
 perla:{face:['#ffffff','#f6f7f8','#e3e6ea'],back:['#fbfcfc','#dfe2e6'],edge:'#b4b8be',edgeUp:'#b8bcc2',edgeBack:'#c2c6cc',edgeStroke:'#7c8189',stroke:'#a5aab2',outline:'#80858d',
  line:'#c3c7cd',lineHand:'#aeb3ba',hi:'rgba(255,255,255,.95)',pip:'#141414',rim:'rgba(255,255,255,.95)',pipIn:'#30333a',rgb:[[252,253,253],[250,251,252],[242,244,246],[214,218,224]],under:'#a5aab2',tex:.35,dark:false},
 negro:{face:['#3a3a3d','#2b2b2e','#1b1b1d'],back:['#363639','#1d1d1f'],edge:'#0d0d0e',edgeUp:'#111112',edgeBack:'#121214',edgeStroke:'#000',stroke:'#4c4c50',outline:'#050505',
  line:'#6b6b70',lineHand:'#77777c',hi:'rgba(255,255,255,.18)',pip:'#f4f0e4',rim:'rgba(0,0,0,.65)',pipIn:'#cfc9ba',rgb:[[70,70,74],[62,62,66],[52,52,56],[30,30,33]],under:'#0b0b0c',tex:.18,dark:true}
};
let TH=null,PREFS={scene:'patio',felt:'bandera',wood:'nogal',tiles:'marfil',pips:'clasico'};
function pipColor(n){return PREFS.pips==='colores'?(TH.dark?({1:'#ff6b6b',2:'#5aa9ff',3:'#5fd38a',4:'#ffb347',5:'#c58cff',6:'#4fd1d9'})[n]:PIPCOL[n]):TH.pip}
// aplica la personalización; si cambia la madera hay que regenerar sus texturas (lo hace textures.js)
function applyTheme(p,rebuild){
 const prev=Object.assign({},PREFS);
 PREFS=Object.assign({},PREFS,p||{});
 if(!TILESETS[PREFS.tiles])PREFS.tiles='marfil';if(!WOODS[PREFS.wood])PREFS.wood='nogal';if(PREFS.felt!=='bandera'&&!FELTS[PREFS.felt])PREFS.felt='bandera';
 TH=TILESETS[PREFS.tiles];
 if(!['patio','ciudad','clasico'].includes(PREFS.scene))PREFS.scene='patio';
 if(rebuild){
  if(typeof AMB!=='undefined')AMB=null;
  if(prev.wood!==PREFS.wood&&typeof buildWood==='function')buildWood();
  if(typeof STATIC!=='undefined')STATIC=null;
  if(typeof RCACHE!=='undefined')for(const k in RCACHE)delete RCACHE[k];
 }}
applyTheme((()=>{try{return JSON.parse(localStorage.getItem('domino.prefs')||'{}')}catch(e){return{}}})(),false);
