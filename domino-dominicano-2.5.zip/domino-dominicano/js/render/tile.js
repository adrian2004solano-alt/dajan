// Dominó Dominicano · render/tile.js
// Ficha plana genérica (mano en el aire, reparto, boca abajo).
// Nota: todos los archivos de js/core, js/game y js/render comparten el mismo ámbito global y se cargan en el orden
// definido en js/app/loader.js (no cambies ese orden sin probar).
// ---- ficha (ejes locales: el largo va en x). Dorso blanco como en el video ----
const PIP={1:[[0,0]],2:[[-1,-1],[1,1]],3:[[-1,-1],[0,0],[1,1]],4:[[-1,-1],[-1,1],[1,-1],[1,1]],5:[[-1,-1],[-1,1],[0,0],[1,-1],[1,1]],6:[[-1,-1],[0,-1],[1,-1],[-1,1],[0,1],[1,1]]};
function rr(x,y,w,h,r){c.beginPath();c.roundRect(x,y,w,h,r)}
function tile(l,w,p1,p2,up,hl,al=1){
 const m=c.getTransform(),sc=Math.hypot(m.a,m.b)/KK,th=Math.max(1.2,w*.1*sc);
 c.globalAlpha=al;
 c.save();c.setTransform(m.a,m.b,m.c,m.d,m.e,m.f+th*KK);rr(-l/2,-w/2,l,w,w*.16);c.fillStyle=up?TH.edgeUp:TH.edgeBack;c.fill();c.restore();
 rr(-l/2,-w/2,l,w,w*.16);
 const g=c.createLinearGradient(0,-w/2,0,w/2);g.addColorStop(0,up?TH.face[0]:TH.back[0]);g.addColorStop(1,up?TH.face[2]:TH.back[1]);c.fillStyle=g;c.fill();
 if(IVORY){c.save();c.globalAlpha=(up?.45:.9)*TH.tex;c.fillStyle=texAt(IVORY,Math.PI/2,w/180,0,0);c.fill();c.restore();rr(-l/2,-w/2,l,w,w*.16)}
 c.lineWidth=Math.max(.8,w*.035);c.strokeStyle=TH.outline;c.stroke();
 if(hl){c.lineWidth=w*.12;c.strokeStyle=hl;c.stroke()}
 if(up){c.beginPath();c.moveTo(0,-w*.4);c.lineTo(0,w*.4);c.strokeStyle=TH.line;c.lineWidth=w*.05;c.stroke();
  for(const[p,cx]of[[p1,-l/4],[p2,l/4]]){const gg=w*.25;c.fillStyle=pipColor(p);for(const[px,py]of(PIP[p]||[])){c.beginPath();c.arc(cx+px*gg,py*gg,w*.085,0,7);c.fill()}}}
 c.globalAlpha=1}
