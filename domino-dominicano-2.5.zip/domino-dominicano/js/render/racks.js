// Dominó Dominicano · render/racks.js
// Atriles 3D de los rivales y del compañero, con sus fichas recostadas (se cachean como imagen).
// Nota: todos los archivos de js/core, js/game y js/render comparten el mismo ámbito global y se cargan en el orden
// definido en js/app/loader.js (no cambies ese orden sin probar).
// ---- atriles 3D de los rivales y del compañero ----
// Mini 3D: un punto (x,y) de la mesa a una altura z (la altura se ve al 88 %).
const HZ=.88,P3=(x,y,z)=>{const s=1/(1+Q*(1-y/BH));return{x:CX+x*s,y:YH+CC*s-z*s*HZ}};
// Cada atril tiene ejes propios: u a lo largo del atril, v hacia el centro de la mesa, z hacia arriba.
// lean: cuánto se recuestan las fichas. Positivo = hacia el centro de la mesa (se apoyan en el labio delantero; así
// las del compañero se inclinan hacia ti y se ve su canto de arriba con luz). Negativo = hacia su dueño (se apoyan en el
// respaldo; así las de los lados enseñan el dorso, como en la mesa de la referencia).
const RKF={2:{o:[0,-74],eu:[1,0],ev:[0,1],lean:.2},3:{o:[-552,BH/2],eu:[0,1],ev:[1,0],lean:-.28},1:{o:[552,BH/2],eu:[0,-1],ev:[-1,0],lean:-.28}};
const LIPZ=20,lipV=f=>f.lean>0?[RT+.4+(LIPZ-7)*f.lean,RT+.4+(LIPZ-7)*f.lean+7.5]:[RT+.5,RT+8]; // dónde va el labio
const rackVR=f=>[Math.min(-21,-RT+(RTZ[1]-7)*f.lean-8),Math.max(lipV(f)[1]+6,RT+(RTZ[1]-7)*f.lean+6)]; // alcance del atril (v)
let IVB=.97; // luz del dorso de las fichas del atril que se está dibujando
// patrón con transformación (rotación/escala/origen) para las texturas
function texAt(pat,ang,sc,ox,oy){if(pat.setTransform)pat.setTransform(new DOMMatrix().translate(ox,oy).rotate(ang*180/Math.PI).scale(sc));return pat}
const RGAP=1.2,RW=40,RT=7.5,RIN=148,RCAP=15,RTZ=[7,87]; // separación, ancho y medio grosor de la ficha del atril, medio largo interior, tope, altura
const rw=(f,u,v)=>[f.o[0]+u*f.eu[0]+v*f.ev[0],f.o[1]+u*f.eu[1]+v*f.ev[1]];
const rp3=(f,u,v,z)=>{const w=rw(f,u,v);return P3(w[0],w[1],z)};
const rackU=(i,n)=>(i-(n-1)/2)*Math.min(RW+RGAP,(2*RIN-RW)/Math.max(1,n-1));
// posición (en pantalla) de la ficha i de n en el atril del jugador p: ahí aterrizan al repartir
function railPos(p,i,n){const f=RKF[p],u=rackU(i,n),P=rp3(f,u,(50-7)*f.lean,50);return{x:P.x,y:P.y,a:Math.PI/2}}
function polyP(P){c.beginPath();P.forEach((q,i)=>i?c.lineTo(q.x,q.y):c.moveTo(q.x,q.y));c.closePath()}
function roundPoly(P,r){const n=P.length,m=(a,b)=>({x:(a.x+b.x)/2,y:(a.y+b.y)/2}),d=(a,b)=>Math.hypot(a.x-b.x,a.y-b.y);c.beginPath();
 const s0=m(P[0],P[1]);c.moveTo(s0.x,s0.y);
 for(let i=1;i<=n;i++){const b=P[i%n],a=P[i-1],nx=P[(i+1)%n],q=m(b,nx),cr=Math.abs((b.x-a.x)*(nx.y-b.y)-(b.y-a.y)*(nx.x-b.x))/(d(a,b)*d(b,nx)+1e-9);
  if(cr<.15)c.lineTo(b.x,b.y);else c.arcTo(b.x,b.y,q.x,q.y,Math.min(r,d(a,b)/2.2,d(b,nx)/2.2))}c.closePath()}
// caras visibles de una caja (la cámara está al frente y arriba, centrada en x=0)
const area=P=>{let a=0;for(let i=0;i<P.length;i++){const p=P[i],q=P[(i+1)%P.length];a+=p.x*q.y-q.x*p.y}return Math.abs(a/2)};
function boxFaces(f,u0,u1,v0,v1,z0,z1,sh=0){const P=(u,v,z)=>rp3(f,u,v-(z-z0)*sh,z),F=[];
 F.push({k:'top',p:[P(u0,v0,z1),P(u1,v0,z1),P(u1,v1,z1),P(u0,v1,z1)]});
 const side=(nu,nv,pts,cu,cv)=>{const nx=nu*f.eu[0]+nv*f.ev[0],ny=nu*f.eu[1]+nv*f.ev[1],cw=rw(f,cu,cv);
  if((ny>.5||(ny>-.5&&Math.abs(nx)>.5&&cw[0]*nx<0))&&area(pts)>2.5)F.push({k:nv>0?'in':nv<0?'out':'end',p:pts})};
 side(0,1,[P(u0,v1,z0),P(u1,v1,z0),P(u1,v1,z1),P(u0,v1,z1)],(u0+u1)/2,v1);
 side(0,-1,[P(u1,v0,z0),P(u0,v0,z0),P(u0,v0,z1),P(u1,v0,z1)],(u0+u1)/2,v0);
 side(1,0,[P(u1,v1,z0),P(u1,v0,z0),P(u1,v0,z1),P(u1,v1,z1)],u1,(v0+v1)/2);
 side(-1,0,[P(u0,v0,z0),P(u0,v1,z0),P(u0,v1,z1),P(u0,v0,z1)],u0,(v0+v1)/2);
 return F}
const shade=(r,g,b,m)=>'rgb('+Math.round(Math.min(255,r*m))+','+Math.round(Math.min(255,g*m))+','+Math.round(Math.min(255,b*m))+')';
// cara de madera: veta a lo largo del atril, luz según hacia dónde mira, bisel claro en el canto de arriba
function woodFace(F,ang){const b={top:1.08,in:.8,end:.62,out:.5}[F.k];
 polyP(F.p);c.fillStyle=woodAt(WOOD_RACK,ang,.4,F.p[0].x,F.p[0].y);c.fill();
 c.fillStyle=b>=1?'rgba(255,226,186,'+((b-1)*2.2)+')':'rgba(10,4,0,'+(1-b)+')';c.fill();
 c.lineWidth=.8;c.strokeStyle='rgba(0,0,0,.65)';c.stroke();
 if(F.k==='top'){c.beginPath();c.moveTo(F.p[3].x,F.p[3].y);c.lineTo(F.p[2].x,F.p[2].y);c.lineWidth=1.1;c.strokeStyle='rgba(255,226,186,.55)';c.stroke()}}
// cara de marfil: cantos redondeados, degradado de arriba a abajo y línea fina entre caras
function ivoryFace(F){const b={top:1.02,in:IVB,end:.8,out:.6}[F.k],P=F.p;roundPoly(P,2.6);
 const C=TH.rgb;
 if(F.k==='top')c.fillStyle=shade(C[0][0],C[0][1],C[0][2],b);
 else{const g=c.createLinearGradient(P[3].x,P[3].y,P[0].x,P[0].y);g.addColorStop(0,shade(C[1][0],C[1][1],C[1][2],b));g.addColorStop(.5,shade(C[2][0],C[2][1],C[2][2],b));g.addColorStop(1,shade(C[3][0],C[3][1],C[3][2],b));c.fillStyle=g}
 c.fill();
 // textura de marfil (veta a lo largo de la ficha)
 const up=Math.atan2(P[3].y-P[0].y,P[3].x-P[0].x);c.save();c.globalAlpha=(F.k==='top'?.6:.75)*TH.tex;c.fillStyle=texAt(IVORY,up-Math.PI/2,.2,P[0].x,P[0].y);c.fill();c.restore();
 if(F.k==='in'){ // canto de arriba redondeado: luz suave (mate, sin brillo de plástico)
  const g=c.createLinearGradient(P[3].x,P[3].y,P[0].x,P[0].y);g.addColorStop(0,'rgba(255,250,235,.4)');g.addColorStop(.1,'rgba(255,250,235,.08)');g.addColorStop(.2,'rgba(255,255,255,0)');g.addColorStop(.75,'rgba(60,45,20,0)');g.addColorStop(1,'rgba(60,45,20,.2)');c.fillStyle=g;c.fill()}
 if(F.k!=='top'){ // bisel: luz suave en un borde y sombra en el otro
  const g=c.createLinearGradient(P[0].x,P[0].y,P[1].x,P[1].y);g.addColorStop(0,'rgba(255,250,235,.26)');g.addColorStop(.18,'rgba(255,255,255,0)');g.addColorStop(.8,'rgba(0,0,0,0)');g.addColorStop(1,'rgba(70,52,20,.2)');c.fillStyle=g;c.fill()}
 else{c.beginPath();c.moveTo(P[3].x,P[3].y);c.lineTo(P[2].x,P[2].y);c.lineWidth=.8;c.strokeStyle='rgba(255,250,235,.55)';c.stroke();roundPoly(P,2.6)}
 c.lineWidth=.75;c.strokeStyle=TH.dark?'rgba(0,0,0,.8)':'rgba(95,80,52,.66)';c.stroke()}
function drawRack3(p){T2();const f=RKF[p],n=phase==='pick'?Math.max(7,shown[p]):shown[p],near=p===3?1:p===1?-1:0,[l0,l1]=lipV(f);
 const A=rp3(f,-50,0,0),B=rp3(f,50,0,0),ang=Math.atan2(B.y-A.y,B.x-A.x);
 const wood=(u0,u1,v0,v1,z0,z1,sh)=>{for(const F of boxFaces(f,u0,u1,v0,v1,z0,z1,sh))woodFace(F,ang)};
 const ivory=(u0,u1,v0,v1,z0,z1,sh)=>{const FF=boxFaces(f,u0,u1,v0,v1,z0,z1,sh);for(const F of FF){polyP(F.p);c.fillStyle=TH.under;c.fill()}for(const F of FF)ivoryFace(F)};
 const cap=sg=>wood(sg>0?RIN:-RIN-RCAP,sg>0?RIN+RCAP:-RIN,f.lean>0?-18:-32,l1+3,0,36);
 const fw=f.lean>0;                              // ¿se recuestan hacia adelante?
 wood(-RIN-RCAP,RIN+RCAP,fw?-18:-32,l1+3,0,7);   // base
 if(fw)wood(-RIN,RIN,-18,-RT-.5,7,30);           // respaldo bajo (las fichas se separan de él)
 else wood(-RIN,RIN,-17,-RT,7,50,-f.lean);       // respaldo inclinado (las fichas se recuestan en él)
 if(near)cap(-near);else{cap(-1);cap(1)}         // topes que quedan detrás de las fichas
 polyP([rp3(f,-RIN,-RT-.5,7.05),rp3(f,RIN,-RT-.5,7.05),rp3(f,RIN,l0,7.05),rp3(f,-RIN,l0,7.05)]);c.fillStyle='rgba(12,5,1,.9)';c.fill(); // ranura
 IVB=fw?.84:.97;                                  // inclinadas hacia ti, el dorso mira un poco hacia abajo: algo más oscuro
 const us=[];for(let i=0;i<shown[p];i++)us.push(rackU(i,n));
 us.sort((a,b)=>near?(a-b)*near:Math.abs(b)-Math.abs(a)); // de atrás hacia adelante
 for(const u of us)ivory(u-RW/2,u+RW/2,-RT,RT,RTZ[0],RTZ[1],-f.lean); // recostadas
 wood(-RIN,RIN,l0,l1,7,LIPZ);                    // labio delantero
 if(near)cap(near)}
// Cada atril se dibuja en una imagen aparte y solo se vuelve a dibujar cuando cambia su número de fichas
const RCACHE={};
function rackImg(p){const key=shown[p]+'|'+(phase==='pick'?7:shown[p])+'|'+dpr+'|'+k+'|'+PREFS.tiles+PREFS.wood,C=RCACHE[p];if(C&&C.key===key)return C;
 const f=RKF[p];let x0=1e9,y0=1e9,x1=-1e9,y1=-1e9;
 for(const u of[-RIN-RCAP,RIN+RCAP])for(const v of rackVR(f))for(const z of[0,RTZ[1]]){const q=rp3(f,u,v,z);x0=Math.min(x0,q.x);y0=Math.min(y0,q.y);x1=Math.max(x1,q.x);y1=Math.max(y1,q.y)}
 x0=Math.floor(x0-4);y0=Math.floor(y0-4);x1=Math.ceil(x1+4);y1=Math.ceil(y1+4);
 const sc=Math.max(2,dpr*k*1.15),off=(C&&C.off)||document.createElement('canvas');off.width=Math.ceil((x1-x0)*sc);off.height=Math.ceil((y1-y0)*sc);
 const sv=[c,KK,DX,DY,ROT,SCL,SHX,SHY];c=off.getContext('2d');KK=sc;DX=-x0*sc;DY=-y0*sc;ROT=0;SCL=1;SHX=SHY=0;
 try{drawRack3(p)}finally{[c,KK,DX,DY,ROT,SCL,SHX,SHY]=sv}
 return RCACHE[p]={key,off,x0,y0,w:x1-x0,h:y1-y0}}
