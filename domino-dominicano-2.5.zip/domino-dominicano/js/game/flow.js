// Dominó Dominicano · game/flow.js
// Lo que se ve en la mesa: barajar, tomar fichas, poner una ficha, pasar, pase corrido, capicúa y el golpe del final.
// Las reglas las decide el motor (shared/engine.js) en el servidor o en el modo práctica; aquí solo se muestran.
// Nota: todos los archivos de js/core, js/game y js/render comparten el mismo ámbito global y se cargan en el orden
// definido en js/app/loader.js (no cambies ese orden sin probar).

// ---- la mesa actual ----
// Asientos en pantalla: 0 tú (abajo), 1 derecha, 2 enfrente, 3 izquierda.
// 1 vs 1: 0 y 2 · tríos: 0, 1 (derecha) y 3 (izquierda) · parejas: los cuatro.
let MODE='parejas',NSEAT=4,ME=0,SEATS=[],STAKE=0,ONLINE=false,DEAL=7,TARGETP=200;
const TRIO_SEATS=[0,1,3];
const seatOf=p=>NSEAT===2?(p===ME?0:2):NSEAT===3?TRIO_SEATS[(p-ME+3)%3]:(p-ME+4)%4;
const pOf=seat=>NSEAT===2?(seat===0?ME:1-ME):NSEAT===3?(ME+TRIO_SEATS.indexOf(seat))%3:(seat+ME)%4;
const baseSeats=()=>NSEAT===2?[0,2]:NSEAT===3?[0,1,3]:[0,1,2,3];
const isOut=s=>!!(SEATS[s]&&SEATS[s].out);
const activeSeats=()=>baseSeats().filter(s=>s===0||!isOut(s));
const rackSeats=()=>NSEAT===2?[2]:NSEAT===3?[3,1]:[2,3,1];
const myTeam=()=>NSEAT===4?ME%2:ME;
const seatName=s=>s===0?'Tú':((SEATS[s]&&SEATS[s].name)||NAMES[s]);
const seatIsMine=s=>NSEAT===4?s%2===0:s===0; // mi equipo (o yo)
// a quién van los puntos de un asiento: en parejas "Nosotros/Ellos", si no el nombre del jugador
const whoLabel=s=>NSEAT===4?(seatIsMine(s)?'Nosotros':'Ellos'):(s===0?'ti':seatName(s));
// marcador desde mi lado: [[nombre, puntos], …] (yo / mi equipo primero)
function scoreCols(sc){if(NSEAT===4){const t=myTeam();return[['Nosotros',sc[t]],['Ellos',sc[1-t]]]}
 return baseSeats().map(s=>[(s===0?'Tú':seatName(s))+(isOut(s)?' (se fue)':''),sc[pOf(s)]])}
const prizeOf=stake=>stake*(NSEAT===4?2:NSEAT);

let legalNow=[];        // tus jugadas posibles (las manda el motor en tu turno)
const tileObj=id=>{const t=DomEngine.tileOf(id);return{a:t[0],b:t[1],id}};

function shuffleArr(a){for(let i=a.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[a[i],a[j]]=[a[j],a[i]]}return a}
function resetTable(){
 chain=[];ends={};capFx=null;corrido=null;corridoFx=null;shakes=[];endFx=null;chainVer++;RPC.clear();centerEnds=null;bonuses=[];
 H=[];shown=[0,0,0,0];got=[0,0,0,0];flights=[];passes=0;bubbles=[];pendingEnd=null;passBtn=null;knock=null;sel=-1;drag=null;legalNow=[];pozoN=0;
}
// barajar: las fichas que quedaron en la mesa (o unas nuevas) se revuelven y luego van a su lugar (pos viene del motor)
let targetPos=null,pozoN=0;
function startShuffle(pos,rno){
 resetTable();round=rno||round+1;targetPos=pos;
 if(deck.length===28)deck=deck.map((d,i)=>({i,x:d.x,y:d.y,a:d.a,tx:d.x,ty:d.y,ta:d.a,taken:false}));
 else deck=Array.from({length:28},(_,i)=>({i,x:rnd2(-300,300),y:rnd2(100,380),a:rnd2(0,6.28),tx:0,ty:0,ta:0,taken:false}));
 phase='shuffle';ph0=now;shuf0=0;document.getElementById('modal').style.display='none';updScore()}
const rnd2=(a,b)=>a+Math.random()*(b-a);
function settleToTarget(){if(!targetPos)return;deck.forEach((d,i)=>{const q=targetPos[i];d.tx=q.x;d.ty=q.y;d.ta=q.a})}
function deckAt(p){const b=inv(p.x,p.y);
 for(let i=deck.length-1;i>=0;i--){const d=deck[i];if(d.taken||d.pozo)continue;const dx=b.x-d.x,dy=b.y-d.y,co=Math.cos(d.a),si=Math.sin(d.a);
  if(Math.abs(dx*co+dy*si)<L/2+4&&Math.abs(-dx*si+dy*co)<W/2+4)return d}return null}
// una ficha de la mesa vuela a la mano de alguien (t: la ficha, solo si es tuya)
function startPick(d,seat,t){
 d.taken=true;d.pending=0;const P=proj(d.x,d.y),P1=proj(d.x+Math.cos(d.a),d.y+Math.sin(d.a)),i=got[seat]++;
 const to=seat===0?{x:CX+(i-3)*STEP,y:HY,a:Math.PI/2,sc:1}:Object.assign(railPos(seat,i,Math.max(DEAL,shown[seat]+1)),{sc:.28});
 flights.push({d,seat,t,i,t0:now,dur:seat===0?520:640,x0:P.x,y0:P.y,a0:Math.atan2(P1.y-P.y,P1.x-P.x),sc0:L*P.s/HL,lift:d.lift||0,to});snd('pick')}
// 1 vs 1: las fichas que sobran se apilan en el pozo, a la izquierda
const POZO_X=-524;
function pozoSlot(k){const col=k%7,lay=Math.floor(k/7);return{x:POZO_X,y:78+col*54,a:Math.PI/2,lift:lay*6}}
function makePozo(idx){let k=0;for(const i of idx){const d=deck[i];if(!d)continue;const q=pozoSlot(k++);d.pozo=true;d.tx=q.x;d.ty=q.y;d.ta=q.a;d.lift=q.lift}pozoN=k}
function drawFromPozo(seat,t){const ps=deck.filter(d=>d.pozo&&!d.taken);const d=ps[ps.length-1];if(!d)return;d.pozo=false;startPick(d,seat,t);pozoN=Math.max(0,pozoN-1)}

const CAPD=3000,CAPR=240; // duración de la animación de capicúa / tiempo de subida del golpe
let capFx=null;
// alguien pone una ficha (s: dónde va, calculado por layout.js; from: de dónde sale volando)
function playVisual(seat,t,s,from){
 chainVer++;RPC.clear();
 const bt=Object.assign({},s.pl);bt.arm=s.name;bt.seat=seat;
 if(s.name==='C'){chain=[bt];ends=s.ends;ends.L.tile=ends.R.tile=bt;centerEnds={L:Object.assign({},s.ends.L),R:Object.assign({},s.ends.R)}}
 else{
  if(s.pl.rp){const rp=s.pl.rp;rp.arm.forEach((tl,i)=>{const g=rp.res[i];tl.mv={t0:now,fx:tl.x,fy:tl.y,fa:tl.ang};tl.x=g.cx;tl.y=g.cy;tl.ang=g.ang});}
  chain.push(bt);ends[s.name]=s.pl.end;s.pl.end.tile=bt;}
 if(from)bt.anim={t0:now,dur:seat===0?240:480,fx:from.x,fy:from.y,fa:from.a};
 if(seat===0)H=H.filter(i=>i.t.id!==t.id);else shown[seat]=Math.max(0,shown[seat]-1);
 sel=-1;hover=-1;drag=null;passes=0;passBtn=null;legalNow=[];
 return bt}
// dónde va una ficha según la punta que eligió el motor
function slotFor(t,end){
 if(end==='C'||!chain.length)return centerSlot(t);
 return{name:end,pl:place(ends[end],t,end)}}

// Paso: una ficha sale, golpea la mesa dos veces (tan, tan) y vuelve
// Pase normal: +25 para el equipo de quien jugó. Pase corrido: +30 (los otros tres pasan solos).
const PASE_PTS=DomEngine.PASE_PTS,CORRIDO_PTS=DomEngine.CORRIDO_PTS;let bonuses=[],corrido=null,corridoFx=null;
function sndCoin(hi){if(muted)return;try{AC=AC||new(window.AudioContext||window.webkitAudioContext)();const t=AC.currentTime;
 [[988,0],[1319,.09]].forEach(([f,d])=>{const o=AC.createOscillator(),g=AC.createGain();o.type='triangle';o.frequency.value=f*(hi?1.26:1);
  g.gain.setValueAtTime(0,t+d);g.gain.linearRampToValueAtTime(.35,t+d+.01);g.gain.exponentialRampToValueAtTime(.001,t+d+.35);o.connect(g);g.connect(AC.destination);o.start(t+d);o.stop(t+d+.4)})}catch(e){}}
function giveBonus(giverSeat,passerSeat,pts,kind,newScores){const el=document.getElementById('score');
 const tx=((el.offsetLeft+el.offsetWidth/2)-ox)/k,ty=((el.offsetTop+el.offsetHeight/2)-oy)/k;
 bonuses.push({mine:seatIsMine(giverSeat),who:whoLabel(giverSeat),giver:giverSeat,passer:passerSeat,pts,kind,t0:now,tx,ty,done:false,seed:Math.random()*9,scores:newScores});sndCoin(false)}
function applyBonus(b){if(b.done)return;b.done=true;if(b.scores)scores=b.scores.slice();updScore();sndCoin(true);
 const el=document.getElementById('score');el.classList.remove('pulse');void el.offsetWidth;el.classList.add('pulse')}
function passVisual(seat){
 bubbles.push({p:seat,t0:now});passes++;passBtn=null;sel=-1;drag=null;
 knock={p:seat,t0:now,dur:1300,ki:seat===0?Math.floor(Math.random()*Math.max(1,H.length)):0,h:[0,0]}}
function knockSt(){const u=clamp((now-knock.t0)/knock.dur);
 const out=ease(clamp(u/.15))-ease(clamp((u-.88)/.12));
 const arc=(u>.2&&u<.45)?Math.sin(Math.PI*(u-.2)/.25):(u>.55&&u<.8)?Math.sin(Math.PI*(u-.55)/.25):0;return{u,out,arc}}
function seatFrom(p){return p===1?{x:BW/2+90,y:BH/2+rnd2(-40,40),a:Math.PI/2}:p===3?{x:-BW/2-90,y:BH/2+rnd2(-40,40),a:Math.PI/2}:{x:rnd2(-40,40),y:-90,a:0}}
function fromItem(it){const q=inv(it.x,it.y);return{x:q.x,y:q.y,a:it.ang}}

// FIN DE LA MANO: quien gana le da duro a la mesa (solo se siente la vibración), las fichas de la mesa saltan y se
// desordenan, las de todos los atriles caen a la mesa, todas se voltean boca abajo y de ahí mismo se barajan.
let endFx=null,endMsg=null;
function freeSpot(placed,a){for(let k=0;k<400;k++){const q={x:rnd2(-BW/2+52,BW/2-52),y:rnd2(52,BH-60),a};if(placed.every(p=>!obbHit(p,q,4)))return q}
 return{x:rnd2(-BW/2+52,BW/2-52),y:rnd2(52,BH-60),a}}
function obbHit(a,b,m){const ax=[[Math.cos(a.a),Math.sin(a.a)],[-Math.sin(a.a),Math.cos(a.a)],[Math.cos(b.a),Math.sin(b.a)],[-Math.sin(b.a),Math.cos(b.a)]];
 const dx=b.x-a.x,dy=b.y-a.y;
 for(const[nx,ny]of ax){const ra=(L/2+m)*Math.abs(Math.cos(a.a)*nx+Math.sin(a.a)*ny)+(W/2+m)*Math.abs(-Math.sin(a.a)*nx+Math.cos(a.a)*ny),
  rb=(L/2+m)*Math.abs(Math.cos(b.a)*nx+Math.sin(b.a)*ny)+(W/2+m)*Math.abs(-Math.sin(b.a)*nx+Math.cos(b.a)*ny);if(Math.abs(dx*nx+dy*ny)>ra+rb)return false}
 return true}
function startEndSlam(res){
 snd('slam',1.6);setTimeout(()=>snd('slam',1.1),45);setTimeout(()=>snd('knock',1),90);
 shakes.push({t0:now,amp:17,dur:900});
 const placed=[],items=[];
 for(const t of chain){const x0=t.x+(t.jx||0),y0=t.y+(t.jy||0),a0=t.ang+(t.ja||0);let q=null;
  for(let k=0;k<14&&!q;k++){const r=(k<10?14+Math.random()*30:6+Math.random()*10),th=Math.random()*6.283,c2={x:clamp(x0+Math.cos(th)*r,-BW/2+44,BW/2-44),y:clamp(y0+Math.sin(th)*r,44,BH-44),a:a0+rnd2(-.7,.7)};
   if(placed.every(p=>!obbHit(p,c2,1.5)))q=c2}
  if(!q)q={x:x0,y:y0,a:a0};placed.push(q);
  items.push({t:{a:t.p1,b:t.p2},x:x0,y:y0,a:a0,tx:q.x,ty:q.y,ta:q.a,taken:false,flip:now+520,face:true,hopT:now,hop:10+Math.random()*16})}
 // las fichas que quedaban en las manos caen a la mesa (las tuyas boca arriba, que se voltean)
 for(const seat of activeSeats()){
  const n=seat===0?H.length:shown[seat];
  for(let i=0;i<n;i++){let from,t=null;
   if(seat===0){const it=H[i];t=it.t;const b=inv(it.x,Math.min(it.y,500));from={x:b.x,y:b.y}}
   else{const r=railPos(seat,i,n),b=inv(r.x,r.y);from={x:clamp(b.x,-BW/2-60,BW/2+60),y:clamp(b.y,-70,BH+40)}}
   const q=freeSpot(placed,rnd2(0,6.28));placed.push(q);
   items.push({t:t||{a:0,b:0},x:from.x,y:from.y,a:seat===0?Math.PI/2:rnd2(0,6.28),tx:q.x,ty:q.y,ta:q.a,taken:false,flip:seat===0?now+620:0,face:seat===0,hopT:now+60*i,hop:22})}}
 // el pozo (1 vs 1) también se revuelve
 for(const d of deck)if(d.pozo&&!d.taken){const q=freeSpot(placed,rnd2(0,6.28));placed.push(q);items.push({t:{a:0,b:0},x:d.x,y:d.y,a:d.a,tx:q.x,ty:q.y,ta:q.a,taken:false,hopT:now,hop:14})}
 while(items.length<28){const q=freeSpot(placed,rnd2(0,6.28));placed.push(q);items.push({t:{a:0,b:0},x:q.x,y:q.y,a:q.a,tx:q.x,ty:q.y,ta:q.a,taken:false})}
 chain=[];ends={};H=[];shown=[0,0,0,0];sel=-1;hover=-1;drag=null;passBtn=null;legalNow=[];
 items.forEach((d,i)=>d.i=i);deck=items.slice(0,28);
 endMsg={t0:now,txt:res.title};
 endFx={t0:now}}
// resultado de la mano en palabras
function roundTitle(r){
 const w=r.winner>=0?seatOf(r.winner):-1,pts=r.pts&&w>=0?' · +'+r.pts+' para '+whoLabel(w):'';
 if(r.kind==='abandon')return w===0?'Los demás se fueron: ¡ganaste la partida!':'Se fueron los demás: gana '+seatName(w);
 if(r.kind==='domino')return(r.cap?'¡CAPICÚA! ':'¡Dominó! ')+(w===0?'Ganaste tú':'Ganó '+seatName(w))+pts+(r.cap?' (incluye 25 de capicúa)':'');
 if(r.team<0)return'¡Mano trancada! Empate, nadie suma';
 return'¡Mano trancada! Gana '+(NSEAT===4?whoLabel(w):(w===0?'tú':seatName(w)))+pts}
function updScore(){const cols=scoreCols(scores);
 document.getElementById('score').innerHTML='<table><tr>'+cols.map(c=>'<td>'+esc(c[0])+'</td>').join('')+'</tr><tr>'+cols.map(c=>'<td>'+(c[1]||0)+'</td>').join('')+'</tr></table><small>Mano '+round+' · a '+TARGETP+(TARGETP===100?' (rápida)':'')+(STAKE?' · mesa de '+money(STAKE):'')+'</small>'}
const esc=s=>String(s).replace(/[&<>"']/g,ch=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'})[ch]);
document.getElementById('mute').onclick=e=>{muted=!muted;e.currentTarget.textContent=muted?'🔇':'🔊';try{localStorage.setItem('domino.muted',muted?'1':'0')}catch(_){}};
