// Dominó Dominicano · game/state.js
// Estado de la partida y geometría básica de la mesa.
// Nota: todos los archivos de js/core, js/game y js/render comparten el mismo ámbito global y se cargan en el orden
// definido en js/app/loader.js (no cambies ese orden sin probar).
// ---- estado ----
let phase='shuffle',ph0=0,pickOpen=0,deck=[],flights=[],got=[0,0,0,0],nextPick=[0,0,0,0],hands=[[],[],[],[]],H=[],shown=[0,0,0,0],chain=[],ends={},turn=0,turnT0=0,turnDur=25000,botAt=0,passes=0,bubbles=[],scores=[0,0],round=0,req66=true,starter=0,toast=null,drag=null,sel=-1,hover=-1,hoverDeck=null,passBtn=null,pendingEnd=null,knock=null,ptr={x:0,y:0},shuf0=0,gameOver=false,prevSel=-1;
const PB={x:1150,y:545,r:40};
const nHome=()=>(phase==='play'||phase==='roundEnd')?H.length:Math.max(7,H.length);
const handStep=()=>Math.min(STEP,440/Math.max(1,nHome()-1));
const home=i=>({x:CX+(i-(nHome()-1)/2)*handStep(),y:HY});
// ---- geometría de la mesa ----
const FA=proj(-BW/2,0),FB=proj(BW/2,0),FD=proj(BW/2,BH),FE=proj(-BW/2,BH);
const edgeL=t=>({x:lerp(FA.x,FE.x,t)-RO,y:lerp(FA.y,FE.y,t)}),edgeR=t=>({x:lerp(FB.x,FD.x,t)+RO,y:lerp(FB.y,FD.y,t)});
const angL=Math.atan2(FE.y-FA.y,FE.x-FA.x),angR=Math.atan2(FD.y-FB.y,FD.x-FB.x);
