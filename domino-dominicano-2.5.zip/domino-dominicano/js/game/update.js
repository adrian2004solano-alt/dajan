// Dominó Dominicano · game/update.js
// Actualización por cuadro: animaciones, eventos en cola, vibraciones y movimiento de la mano.
// Nota: todos los archivos de js/core, js/game y js/render comparten el mismo ámbito global.
function update(){
 const tr=phase==='shuffle'?[-.13,.92]:[0,1];ROT+=(tr[0]-ROT)*.07;SCL+=(tr[1]-SCL)*.07;
 if(phase==='shuffle'){
  if(now-shuf0>240){shuf0=now;for(const d of deck){d.tx=rnd(-340,340);d.ty=rnd(80,400);d.ta=d.a+rnd(-2.2,2.2)}}
  for(const d of deck){d.x+=(d.tx-d.x)*.17;d.y+=(d.ty-d.y)*.17;d.a+=(d.ta-d.a)*.17}
  if(now-ph0>2800){phase='pick';settleToTarget();pickOpen=now+1000}}
 else if(phase==='pick'||deck.some(d=>d.pozo)){
  for(const d of deck)if(!d.taken){d.x+=(d.tx-d.x)*.14;d.y+=(d.ty-d.y)*.14;d.a+=angd(d.a,d.ta)*.14}}
 if(phase==='play'||phase==='roundEnd'){
  if(corrido){const C=corrido,ag=now-C.t0,others=activeSeats().filter(s=>s!==C.p),np=C.tranque?others.length+1:others.length,gap=260;
   while(ag>=0&&C.i<np&&ag>=C.i*gap){const o=C.i<others.length?others[C.i]:C.p;bubbles.push({p:o,t0:now});snd('knock');setTimeout(()=>snd('knock'),110);C.i++}
   if(!C.tranque){
    if(ag>=np*gap+120&&!C.fx){C.fx=1;corridoFx={t0:now,p:C.p};giveBonus(C.p,-1,C.pts||CORRIDO_PTS,'corrido',C.scores)}
    if(ag>=np*gap+2000)corrido=null}
   else if(ag>=np*gap+450)corrido=null}
  else if(knock){const s=knockSt();
   if(s.u>=.45&&!knock.h[0]){knock.h[0]=1;snd('knock')}
   if(s.u>=.8&&!knock.h[1]){knock.h[1]=1;snd('knock')}
   if(s.u>=1)knock=null}
  else if(pendingEnd&&!chain.some(t=>t.anim)){
   const pe=pendingEnd;
   if(pe.cap){if(!pe.c0){if(now>=pe.at){pe.c0=now;capFx={c0:now,w:pe.winner,nums:pe.nums,hits:[{n:'L',t:now},{n:'R',t:now+700},{n:'B',t:now+1450}]}}}
    else if(now>=pe.c0+CAPD){pendingEnd=null;scores=pe.res.scores.slice();updScore();startEndSlam({title:roundTitle(pe.res)});phase='roundEnd'}}
   else if(now>=pe.at){pendingEnd=null;updScore();startEndSlam({title:roundTitle(pe.res)});phase='roundEnd'}}}
 for(let i=flights.length-1;i>=0;i--){const f=flights[i];if(now>=f.t0+f.dur){flights.splice(i,1);
  if(f.seat===0&&f.t)H.push({t:f.t,x:f.to.x,y:f.to.y,ang:Math.PI/2,sc:1,al:1});else if(f.seat!==0)shown[f.seat]++;snd('deal')}}
 for(const t of chain)if(t.anim&&now>=t.anim.t0+t.anim.dur){t.anim=null;t.bump=now;snd('place');impact(t)}
 for(const b of bonuses)if(!b.done&&now-b.t0>=1500)applyBonus(b);
 bonuses=bonuses.filter(b=>now-b.t0<1700);
 SHX=SHY=0;
 shakes=shakes.filter(s=>now-s.t0<(s.dur||520));
 for(const s of shakes){const D=s.dur||520,ag=now-s.t0,f=Math.pow(1-ag/D,1.6);SHX+=Math.cos(ag/12)*s.amp*f*.8;SHY+=Math.sin(ag/8.5)*s.amp*f}
 if(capFx)for(const h of capFx.hits){const ag=now-h.t;
  if(ag>=CAPR&&!h.done){h.done=1;snd('slam');if(h.n==='B')setTimeout(()=>snd('slam'),90)}
  if(ag>=CAPR&&ag<CAPR+450){const f=1-(ag-CAPR)/450,am=(h.n==='B'?16:10)*f;SHX+=Math.cos(ag/11)*am*.7;SHY+=Math.sin(ag/8)*am}}
 let pv=null;if(drag&&drag.moved&&inRack(ptr)&&H.includes(drag.it)){const o=H.filter(q=>q!==drag.it);o.splice(rackIdx(ptr),0,drag.it);pv=new Map(o.map((q,j)=>[q,j]))}
 H.forEach((it,i)=>{const hm=home(pv?pv.get(it):i);let tx=hm.x,ty=hm.y,tsc=1,tang=Math.PI/2,sm=.28;
  if(it.pending){tx=it.x;ty=it.y;tsc=it.sc;tang=it.ang;sm=0}
  else if(drag&&drag.it===it){tx=ptr.x;ty=ptr.y;sm=.5;const f=clamp((560-ptr.y)/90);
   tsc=lerp(1.1,L*((ptr.y-YH)/CC)/HL,f);
   const n=canAct()?nearest(it.t,ptr):{s:null,d:1e9};
   if(n.s&&f>.2&&n.d<180){const P=proj(n.s.pl.x,n.s.pl.y),P1=proj(n.s.pl.x+Math.cos(n.s.pl.ang),n.s.pl.y+Math.sin(n.s.pl.ang));
    tang=Math.atan2(P1.y-P.y,P1.x-P.x);if(!n.s.pl.dbl&&n.s.pl.p1!==it.t.a)tang+=Math.PI}}
  else if(knock&&knock.p===0&&H[knock.ki]===it){const s=knockSt();ty=hm.y-62*s.out-36*s.arc;sm=.6}
  else if((i===hover&&canAct())||i===sel){ty-=14;tsc=1.05}
  if(it.shake&&now-it.shake<350)tx+=Math.sin((now-it.shake)/25)*6;
  it.x+=(tx-it.x)*sm;it.y+=(ty-it.y)*sm;it.sc+=(tsc-it.sc)*.3;it.ang+=angd(it.ang,tang)*.3});
 bubbles=bubbles.filter(b=>now-b.t0<1800);
 if(endFx){const ag=now-endFx.t0;for(const d of deck){const k=ag<120?.06:.2;d.x+=(d.tx-d.x)*k;d.y+=(d.ty-d.y)*k;d.a+=angd(d.a,d.ta)*k}if(ag>1450)endFx=null}
 pumpEvents()}
