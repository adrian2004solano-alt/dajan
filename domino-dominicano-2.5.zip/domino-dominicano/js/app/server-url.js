// Dominó Dominicano · dirección del servidor del juego
// Déjalo vacío ('') si la página la sirve el mismo servidor (lo normal: todo en Railway/Render).
// Si la página está en otro sitio (ej. Vercel) y el servidor en otro (ej. Railway), pon aquí la dirección del servidor,
// por ejemplo 'https://domino-dominicano.up.railway.app', y en el servidor ALLOWED_ORIGINS=https://tu-sitio.vercel.app
window.DOMINO_SERVER = window.DOMINO_SERVER || '';
