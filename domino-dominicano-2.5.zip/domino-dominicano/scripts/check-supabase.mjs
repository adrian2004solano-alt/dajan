// Revisa que la conexión con Supabase esté bien hecha, ANTES de publicar el servidor.
// Uso:  SUPABASE_URL=https://xxxx.supabase.co SUPABASE_SECRET_KEY=sb_secret_xxx node scripts/check-supabase.mjs
//       (opcional) SUPABASE_ANON_KEY=… para comprobar que la clave pública NO puede leer nada.
// Solo lee: no crea ni cambia datos.
import { createSupabaseStore } from '../server/store/supabase.js';

const url = process.env.SUPABASE_URL, key = process.env.SUPABASE_SECRET_KEY || process.env.SUPABASE_SERVICE_ROLE_KEY;
const ok = (t) => console.log('  ✔ ' + t), bad = (t) => { console.log('  ✘ ' + t); process.exitCode = 1; };
if (!url || !key) { console.log('Pon SUPABASE_URL y SUPABASE_SECRET_KEY (la clave secreta, no la pública).'); process.exit(1); }
if (!/^https:\/\/[a-z0-9-]+\.supabase\.(co|in)\/?$/.test(url) && !process.env.ALLOW_CUSTOM_URL) console.log('  (aviso) SUPABASE_URL no parece https://<proyecto>.supabase.co — revisa que no tenga /rest/v1 al final.');

console.log('Supabase: ' + url);
let S;
try { S = createSupabaseStore({ url, key }); ok('clave secreta con formato correcto'); } catch (e) { bad(e.message); process.exit(1); }
const need = ['user_get', 'user_by_name', 'guest_create', 'session_create', 'session_user', 'session_delete', 'user_register', 'user_update', 'claim_daily', 'claim_rescue', 'leaderboard', 'history', 'move_coins',
  'chat_add', 'chat_recent', 'chat_get', 'chat_delete', 'report_add', 'match_start', 'match_players', 'match_settle', 'match_void_active',
  'tickets_mine', 'ticket_create', 'ticket_get_mine', 'ticket_add_msg', 'admin_stats', 'admin_tickets', 'admin_ticket', 'admin_reply', 'admin_ticket_close',
  'admin_reports', 'admin_report_resolve', 'admin_chat', 'admin_users', 'admin_mute', 'admin_ban'];
try { await S.call('chat_recent', { n: 1 }); ok('la API responde y la migración está aplicada (dd_chat_recent)'); }
catch (e) { bad(e.message); console.log('\n→ ¿Corriste supabase/migrations/001_domino.sql en el SQL Editor? Si sí, espera 1 minuto (recarga del esquema) y vuelve a probar.'); process.exit(1); }
try { const s = await S.call('admin_stats', { now: Date.now() }); ok(`estadísticas: ${s.users} cuentas, ${s.openTickets} consultas abiertas`); } catch (e) { bad('admin_stats: ' + e.message); }
// que existan todas las funciones (una llamada de solo lectura con datos que no existen)
const readOnly = { user_get: { id: -1 }, user_by_name: { name_lc: '__nadie__' }, session_user: { hash: '0'.repeat(64), now: Date.now() }, leaderboard: {}, history: { uid: -1 }, chat_get: { id: -1 },
  tickets_mine: { uid: -1 }, ticket_get_mine: { id: -1, uid: -1 }, admin_tickets: { status: null }, admin_ticket: { id: -1 }, admin_reports: {}, admin_chat: {}, admin_users: { q: '' } };
let missing = 0;
for (const [n, a] of Object.entries(readOnly)) { try { await S.call(n, a); } catch (e) { missing++; bad(`dd_${n}: ${e.message}`); } }
if (!missing) ok(`las ${Object.keys(readOnly).length} funciones de lectura responden (el juego usa ${need.length} en total)`);
// la clave pública no debe poder leer nada
const anon = process.env.SUPABASE_ANON_KEY || process.env.SUPABASE_PUBLISHABLE_KEY;
if (anon) {
  const h = { apikey: anon, 'Content-Type': 'application/json' }; if (!anon.startsWith('sb_')) h.Authorization = 'Bearer ' + anon;
  const r1 = await fetch(url.replace(/\/+$/, '') + '/rest/v1/users?select=id&limit=1', { headers: h });
  const t1 = await r1.text();
  if (r1.ok && t1.trim() !== '[]') bad('¡La clave pública puede leer la tabla users! Revisa RLS (la migración la activa).'); else ok('la clave pública no puede leer las tablas');
  const r2 = await fetch(url.replace(/\/+$/, '') + '/rest/v1/rpc/dd_admin_stats', { method: 'POST', headers: h, body: '{"p":{"now":0}}' });
  if (r2.ok) bad('¡La clave pública puede ejecutar las funciones dd_*! Corre otra vez la sección SEGURIDAD de la migración.'); else ok('la clave pública no puede ejecutar las funciones del juego');
} else console.log('  (opcional) pon SUPABASE_ANON_KEY para comprobar que la clave pública no tiene acceso.');
console.log(process.exitCode ? '\nHay problemas: revisa los ✘.' : '\nTodo listo: el servidor puede usar Supabase.');
